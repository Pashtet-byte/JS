// Задание 45: Math.floor vs Math.trunc для отрицательных
console.log(Math.floor(-3.1)); // -4
console.log(Math.trunc(-3.1)); // -3
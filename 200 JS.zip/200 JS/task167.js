// Задание 167: NaN ?? "default"
console.log(NaN ?? "default"); // NaN
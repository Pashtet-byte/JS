// Задание 12: parseInt("10px") vs Number("10px")
console.log(parseInt("10px")); // 10
console.log(Number("10px"));   // NaN
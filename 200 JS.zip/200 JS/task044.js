// Задание 44: Округление до 2 знаков
function roundTo2(num) {
  return Math.round(num * 100) / 100;
}
console.log(roundTo2(3.14159)); // 3.14
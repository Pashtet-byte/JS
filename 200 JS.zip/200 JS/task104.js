// Задание 104: Тернарный возраст
const age104 = 20;
const category = age104 >= 18 ? "adult" : "minor";
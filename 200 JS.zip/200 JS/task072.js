// Задание 72: <, >, <=, >=
console.log(5 < 10);  // true
console.log(5 >= 5);  // true
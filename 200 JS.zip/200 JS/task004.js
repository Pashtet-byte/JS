// Задание 4: Boolean(0), Boolean(""), Boolean(null)
console.log(Boolean(0));      // false
console.log(Boolean(""));     // false
console.log(Boolean(null));   // false
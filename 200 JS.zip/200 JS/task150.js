// Задание 150: Функция and
function and(...fns) {
  return (val) => fns.every(fn => fn(val));
}
const isPositiveAndEven = and(x => x > 0, x => x % 2 === 0);
console.log(isPositiveAndEven(4)); // true
// Задание 173: Цепочка ??
console.log(null ?? undefined ?? 0 ?? "hello"); // 0
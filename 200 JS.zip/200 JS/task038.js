// Задание 38: ++x
let y = 5;
console.log(++y); // 6
// Задание 76: 0 == false и "" == false
console.log(0 == false);   // true
console.log("" == false);  // true
// Задание 100: if(0)
let x100 = 0;
if(x100) console.log("true"); else console.log("false"); // false
// Задание 149: Short-circuit с console.log
console.log(true || console.log("hi")); // true, console.log не выполняется
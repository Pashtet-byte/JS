// Задание 192: Цепочка источников данных
const env = {PORT: "8080"};
const config = {port: 3000};
const defaults = {port: 80};

const port = env.PORT ?? config.port ?? defaults.port;
console.log(port); // "8080"
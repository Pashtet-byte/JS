// Задание 153: XOR
function xor(a, b) {
  return !!(a ^ b);
}
console.log(xor(true, false)); // true
console.log(xor(true, true));  // false
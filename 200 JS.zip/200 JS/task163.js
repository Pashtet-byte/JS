// Задание 163: null ?? "default" и undefined ?? "default"
console.log(null ?? "default");      // "default"
console.log(undefined ?? "default"); // "default"
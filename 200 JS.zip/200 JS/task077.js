// Задание 77: [] == false
console.log([] == false); // true
// Задание 13: parseInt("0x1F", 16)
console.log(parseInt("0x1F", 16)); // 31
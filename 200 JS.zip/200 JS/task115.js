// Задание 115: Lookup объект вместо if-else
const commands = {
  start: () => "Starting...",
  stop: () => "Stopping...",
  pause: () => "Pausing..."
};
function execute(cmd) {
  return commands[cmd]?.() ?? "Unknown command";
}
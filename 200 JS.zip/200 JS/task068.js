// Задание 68: null == undefined и null === undefined
console.log(null == undefined);  // true
console.log(null === undefined); // false
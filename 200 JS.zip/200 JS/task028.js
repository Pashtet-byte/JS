// Задание 28: Number([1]), Number([1,2]), Number([])
console.log(Number([1]));   // 1
console.log(Number([1,2])); // NaN
console.log(Number([]));    // 0
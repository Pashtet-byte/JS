// Задание 84: Функция between
function between(val, min, max) {
  return val >= min && val <= max;
}
console.log(between(5, 1, 10)); // true
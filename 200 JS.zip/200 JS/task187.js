// Задание 187: Функция coalesce
function coalesce(...vals) {
  for (let val of vals) {
    if (val !== null && val !== undefined) return val;
  }
  return undefined;
}
console.log(coalesce(null, undefined, 0, 42)); // 0
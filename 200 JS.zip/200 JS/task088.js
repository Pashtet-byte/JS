// Задание 88: Объекты с примитивами через ==
const obj88 = {
  valueOf() { return 42; }
};
console.log(obj88 == 42); // true
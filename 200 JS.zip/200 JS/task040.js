// Задание 40: Math.abs
console.log(Math.abs(-42)); // 42
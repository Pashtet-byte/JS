// Задание 118: Guard clauses
function processValue(val) {
  if (val == null) return "no value";
  if (typeof val !== "number") return "not a number";
  return val * 2;
}
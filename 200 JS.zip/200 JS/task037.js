// Задание 37: x++ потом x
let x = 5;
console.log(x++); // 5
console.log(x);   // 6
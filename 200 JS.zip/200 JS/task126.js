// Задание 126: Функция cond
function cond(pairs) {
  return (val) => {
    for (let [pred, trans] of pairs) {
      if (pred(val)) return trans(val);
    }
  };
}
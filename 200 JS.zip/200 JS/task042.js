// Задание 42: Math.max и Math.min
console.log(Math.max(1, 2, 3)); // 3
console.log(Math.min(1, 2, 3)); // 1
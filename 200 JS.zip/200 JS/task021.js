// Задание 21: [] + [] vs {} + []
console.log([] + []);        // ""
console.log({} + []);        // "[object Object]" или 0 в консоли
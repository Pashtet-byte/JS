// Задание 9: Явное vs неявное преобразование
// Явное:
const explicit = Number("123");
// Неявное:
const implicit = "123" * 1;
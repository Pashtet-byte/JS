// Задание 66: == vs ===
console.log(5 == "5");  // true
console.log(5 === "5"); // false
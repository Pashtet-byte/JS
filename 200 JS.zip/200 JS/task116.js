// Задание 116: Классификация числа
function classifyNumber(n) {
  if (n <= 1) return "neither";
  for (let i = 2; i <= Math.sqrt(n); i++) {
    if (n % i === 0) return "composite";
  }
  return "prime";
}
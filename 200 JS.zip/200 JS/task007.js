// Задание 7: Number(true) и Number(false)
console.log(Number(true));  // 1
console.log(Number(false)); // 0
// Задание 26: valueOf и toString при +obj
const obj = {
  valueOf() { return 42; },
  toString() { return "hello"; }
};
console.log(+obj); // 42 (valueOf вызывается первым)
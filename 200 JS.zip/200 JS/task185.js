// Задание 185: ?? с геттером
const obj185 = {
  get value() { return undefined; }
};
console.log(obj185.value ?? "default"); // "default"
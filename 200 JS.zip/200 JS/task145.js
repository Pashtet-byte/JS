// Задание 145: Проблема val || default для 0
function setCount(count) {
  count = count || 10; // проблема: 0 станет 10
  return count;
}
console.log(setCount(0)); // 10
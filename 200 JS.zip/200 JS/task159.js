// Задание 159: allTrue без every
function allTrue(arr) {
  return arr.reduce((acc, val) => acc && Boolean(val), true);
}
console.log(allTrue([1, 2, 3])); // true
console.log(allTrue([1, 0, 3])); // false
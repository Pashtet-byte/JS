// Задание 14: NaN и проверка на NaN
const nan = NaN;
console.log(Number.isNaN(nan)); // true
console.log(isNaN(nan));        // true (но осторожно)
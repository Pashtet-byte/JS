// Задание 20: Number(null) vs Number(undefined)
console.log(Number(null));      // 0
console.log(Number(undefined)); // NaN
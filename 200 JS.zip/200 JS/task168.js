// Задание 168: ??=
let x168 = null;
x168 ??= 42;
console.log(x168); // 42
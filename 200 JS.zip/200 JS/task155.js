// Задание 155: Compose с проверкой на null
function composeWithNull(...fns) {
  return (val) => {
    return fns.reduce((v, f) => {
      if (v === null) return null;
      return f(v);
    }, val);
  };
}
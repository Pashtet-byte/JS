// Задание 70: "apple" > "banana"
console.log("apple" > "banana"); // false
// Задание 152: Функция not
function not(fn) {
  return (...args) => !fn(...args);
}
const isOdd = not(x => x % 2 === 0);
console.log(isOdd(5)); // true
// Задание 63: Линейная интерполяция
function lerp(a, b, t) {
  return a + (b - a) * t;
}
console.log(lerp(0, 10, 0.5)); // 5
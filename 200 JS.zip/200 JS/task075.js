// Задание 75: Функция isEqual
const isEqual = (a, b) => a === b;
console.log(isEqual(5, 5)); // true
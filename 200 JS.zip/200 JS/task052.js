// Задание 52: Массив целых от a до b
function range(a, b) {
  return Array.from({length: b - a + 1}, (_, i) => a + i);
}
console.log(range(3, 7)); // [3, 4, 5, 6, 7]
// Задание 147: Проверка callback
function callIfFunction(callback) {
  if (callback && typeof callback === "function") {
    return callback();
  }
}
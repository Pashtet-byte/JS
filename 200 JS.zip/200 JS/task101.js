// Задание 101: Чётное/нечётное
function evenOdd(n) {
  if (n % 2 === 0) return "even";
  return "odd";
}
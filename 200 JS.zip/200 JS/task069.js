// Задание 69: null == 0
console.log(null == 0); // false
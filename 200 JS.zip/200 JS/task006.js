// Задание 6: falsy значения в JS
const falsyValues = [false, 0, "", null, undefined, NaN, 0n];
falsyValues.forEach(val => console.log(`${val} is falsy:`, Boolean(val)));
// Задание 119: Strategy pattern
const strategies = {
  add: (a, b) => a + b,
  sub: (a, b) => a - b,
  mul: (a, b) => a * b,
  div: (a, b) => b !== 0 ? a / b : Infinity
};
function calculate(op, a, b) {
  return strategies[op]?.(a, b) ?? "Invalid operation";
}
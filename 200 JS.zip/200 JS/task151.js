// Задание 151: Функция or
function or(...fns) {
  return (val) => fns.some(fn => fn(val));
}
const isStringOrNumber = or(x => typeof x === "string", x => typeof x === "number");
console.log(isStringOrNumber(42)); // true
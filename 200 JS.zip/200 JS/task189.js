// Задание 189: ??= для мемоизации
const memo = {};
function expensive(key) {
  console.log(`Computing ${key}...`);
  return key * 2;
}
function getMemo(key) {
  memo[key] ??= expensive(key);
  return memo[key];
}
console.log(getMemo(21)); // Computing 21... 42
console.log(getMemo(21)); // 42 (без вычисления)
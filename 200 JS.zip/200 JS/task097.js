// Задание 97: NaN boxing
console.log(typeof NaN); // "number"
// Задание 142: "cat" && "dog" и "cat" || "dog"
console.log("cat" && "dog"); // "dog"
console.log("cat" || "dog"); // "cat"
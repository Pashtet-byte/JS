// Задание 180: Ленивая инициализация
class Cache {
  constructor() {
    this._cache = {};
  }
  
  get(key, compute) {
    this._cache[key] ??= compute();
    return this._cache[key];
  }
}
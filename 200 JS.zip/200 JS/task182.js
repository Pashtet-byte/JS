// Задание 182: Полифил для ??
function nullishCoalescing(a, b) {
  return a !== null && a !== undefined ? a : b;
}
console.log(nullishCoalescing(0, 42)); // 0
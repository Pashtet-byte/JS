// Задание 165: "" ?? "default" vs "" || "default"
console.log("" ?? "default"); // ""
console.log("" || "default"); // "default"
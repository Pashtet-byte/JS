// Задание 123: Optional chaining
const obj123 = {a: {b: {c: 42}}};
console.log(obj123?.a?.b?.c); // 42
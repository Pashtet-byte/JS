// Задание 107: Вложенный тернарник
const value107 = 5;
const result107 = value107 > 0 ? "positive" : value107 < 0 ? "negative" : "zero";
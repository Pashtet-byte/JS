// Задание 120: Pattern matching
function match(val, cases) {
  for (let [pred, fn] of cases) {
    if (pred(val)) return fn(val);
  }
}
// Задание 188: a?.b ?? c vs (a?.b) ?? c
// Одинаковы - optional chaining связывает плотнее
const obj188 = {a: {b: null}};
console.log(obj188?.a?.b ?? "default"); // "default"
console.log((obj188?.a?.b) ?? "default"); // "default"
// Задание 103: Fallthrough в switch
function testSwitch(val) {
  switch(val) {
    case 1:
    case 2:
    case 3:
      return "1-3";
    case 4:
      return "4";
  }
}
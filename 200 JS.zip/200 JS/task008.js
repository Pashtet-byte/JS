// Задание 8: Boolean([]) и Boolean({})
console.log(Boolean([])); // true
console.log(Boolean({})); // true
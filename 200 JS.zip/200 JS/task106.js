// Задание 106: switch со строками
function getColor(color) {
  switch(color) {
    case "red": return "#ff0000";
    case "green": return "#00ff00";
    case "blue": return "#0000ff";
    default: return "#000000";
  }
}
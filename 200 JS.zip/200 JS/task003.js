// Задание 3: Что вернёт Number("") и Number(" ")
console.log(Number(""));   // 0
console.log(Number(" "));  // 0
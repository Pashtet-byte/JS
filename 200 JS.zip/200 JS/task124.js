// Задание 124: Функция pipe с условием
function pipe(...fns) {
  return (initial) => fns.reduce((v, f) => v != null ? f(v) : v, initial);
}
// Задание 18: parseFloat("3.14abc")
console.log(parseFloat("3.14abc")); // 3.14
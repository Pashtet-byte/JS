// Задание 30: Кастомный [Symbol.toPrimitive]
const customObj = {
  [Symbol.toPrimitive](hint) {
    return hint === "number" ? 100 : "obj";
  }
};
console.log(+customObj); // 100
console.log(String(customObj)); // "obj"
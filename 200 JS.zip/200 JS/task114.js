// Задание 114: Short-circuit evaluation
const user114 = {name: "John"};
user114 && console.log(user114.name); // "John"
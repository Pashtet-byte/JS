// Задание 146: !! значений
console.log(!!"");     // false
console.log(!!0);      // false
console.log(!!null);   // false
console.log(!!NaN);    // false
// Задание 22: +"", +[], +{}, +null
console.log(+"");    // 0
console.log(+[]);    // 0
console.log(+{});    // NaN
console.log(+null);  // 0
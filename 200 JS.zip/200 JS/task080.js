// Задание 80: undefined > 0, < 0, == 0
console.log(undefined > 0);  // false
console.log(undefined < 0);  // false
console.log(undefined == 0); // false
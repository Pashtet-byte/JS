// Задание 172: Когда использовать ?? вместо ||
function configure(options) {
  const port = options.port ?? 3000;
  const host = options.host ?? "localhost";
  const debug = options.debug ?? false;
  return {port, host, debug};
}
console.log(configure({port: 0})); // {port: 0, host: "localhost", debug: false}
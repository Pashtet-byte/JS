// Задание 60: Округление до n знаков
function round(num, precision) {
  return Math.round(num * 10 ** precision) / 10 ** precision;
}
console.log(round(3.14159, 2)); // 3.14
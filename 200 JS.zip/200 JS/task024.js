// Задание 24: Number(Symbol("test"))
try {
  console.log(Number(Symbol("test")));
} catch(e) {
  console.log("TypeError: Cannot convert a Symbol value to a number");
}
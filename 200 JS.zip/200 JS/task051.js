// Задание 51: Функция clamp
function clamp(val, min, max) {
  return Math.min(Math.max(val, min), max);
}
console.log(clamp(15, 0, 10)); // 10
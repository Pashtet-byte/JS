// Задание 141: Параметр по умолчанию без ES6
function greet(name) {
  name = name || "World";
  return `Hello, ${name}!`;
}
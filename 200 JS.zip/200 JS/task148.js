// Задание 148: Приоритет операторов
console.log(true || false && false); // true (&& выше)
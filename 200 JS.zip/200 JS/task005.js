// Задание 5: String(123) и (123).toString()
console.log(String(123));      // "123"
console.log((123).toString()); // "123"
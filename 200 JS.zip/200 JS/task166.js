// Задание 166: false ?? "default"
console.log(false ?? "default"); // false
// Задание 62: Сумма цифр числа
function sumDigits(n) {
  return String(Math.abs(n)).split('').reduce((sum, d) => sum + Number(d), 0);
}
console.log(sumDigits(123)); // 6
// Задание 170: ??= с null
let z170 = null;
z170 ??= 42;
console.log(z170); // 42
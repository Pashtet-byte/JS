// Задание 27: parseInt vs Math.trunc
console.log(parseInt("42.5")); // 42
console.log(Math.trunc(42.5)); // 42
// Разница: parseInt парсит строку, Math.trunc работает с числом
// Задание 29: BigInt
const bigNum = BigInt(42);     // 42n
const backToNum = Number(42n); // 42
console.log(bigNum, backToNum);
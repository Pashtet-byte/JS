// Задание 25: Функция safeNumber
function safeNumber(val) {
  const num = Number(val);
  return isNaN(num) ? 0 : num;
}
console.log(safeNumber("123")); // 123
console.log(safeNumber("abc")); // 0
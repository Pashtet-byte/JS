// Задание 83: "abc" >= "abc"
console.log("abc" >= "abc"); // true
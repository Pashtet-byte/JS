// Задание 157: Proxy с логическими операторами
const proxy157 = new Proxy({value: 42}, {
  get(target, prop) {
    if (prop === Symbol.toPrimitive) {
      return () => target.value;
    }
    return target[prop];
  }
});
console.log(proxy157 && true); // true
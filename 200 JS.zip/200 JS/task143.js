// Задание 143: Короткий вызов функции
const user143 = {login: () => console.log("Logging in...")};
user143 && user143.login();
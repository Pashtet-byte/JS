// Задание 117: Fallthrough пример
switch(2) {
  case 1:
  case 2:
  case 3:
    console.log("1-3"); // выведет это
    break;
}
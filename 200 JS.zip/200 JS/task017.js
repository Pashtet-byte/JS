// Задание 17: toString(2) для числа 10
console.log((10).toString(2)); // "1010"
// Задание 139: null || undefined || 0 || "" || "hello"
console.log(null || undefined || 0 || "" || "hello"); // "hello"
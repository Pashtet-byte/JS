// Задание 193: Хелпер withDefault
function withDefault(obj, defaults) {
  return new Proxy(obj, {
    get(target, prop) {
      return target[prop] ?? defaults[prop];
    }
  });
}
const config193 = withDefault({timeout: 5000}, {timeout: 3000, host: "localhost"});
console.log(config193.timeout); // 5000
console.log(config193.host);    // "localhost"
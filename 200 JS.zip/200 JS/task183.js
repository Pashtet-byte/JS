// Задание 183: ?? с Proxy
const handler183 = {
  get(target, prop) {
    return prop in target ? target[prop] : null;
  }
};
const proxy183 = new Proxy({}, handler183);
console.log(proxy183.unknown ?? "default"); // "default"
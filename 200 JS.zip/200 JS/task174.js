// Задание 174: Смешивание ?? с && и ||
try {
  console.log(null ?? undefined && "x");
} catch(e) {
  console.log("SyntaxError: need parentheses");
}
console.log((null ?? undefined) && "x"); // undefined
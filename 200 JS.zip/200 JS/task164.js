// Задание 164: 0 ?? "default" vs 0 || "default"
console.log(0 ?? "default"); // 0
console.log(0 || "default"); // "default"
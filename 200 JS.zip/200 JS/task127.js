// Задание 127: Code smell - глубокая вложенность
// Плохо:
function badExample(x) {
  if (x) {
    if (x > 0) {
      if (x < 10) {
        return x;
      }
    }
  }
}

// Хорошо:
function goodExample(x) {
  if (!x) return null;
  if (x <= 0) return null;
  if (x >= 10) return null;
  return x;
}
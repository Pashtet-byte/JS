// Задание 47: Гипотенуза
function hypotenuse(a, b) {
  return Math.hypot(a, b);
}
console.log(hypotenuse(3, 4)); // 5
// Задание 15: typeof NaN
console.log(typeof NaN); // "number"
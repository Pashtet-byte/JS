// Задание 64: Unsigned right shift
console.log(-4 >>> 1); // 2147483646
// Задание 94: Abstract Equality Comparison
// Алгоритм == в спецификации ECMA-262
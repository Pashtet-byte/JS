// Задание 92: new String("a") == "a" и === "a"
console.log(new String("a") == "a");  // true
console.log(new String("a") === "a"); // false
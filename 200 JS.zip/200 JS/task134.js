// Задание 134: 0 && "hello"
console.log(0 && "hello"); // 0
// Задание 73: 1 < 2 < 3 и 3 > 2 > 1
console.log(1 < 2 < 3); // true (1<2=true, true<3 => 1<3)
console.log(3 > 2 > 1); // false (3>2=true, true>1 => 1>1)
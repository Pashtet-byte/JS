// Задание 138: true && false || true
console.log(true && false || true); // true
// Задание 46: Infinity
console.log(1 / 0);  // Infinity
console.log(-1 / 0); // -Infinity
// Задание 2: Преобразуй строку "42" в число тремя способами
const str = "42";
const num1 = Number(str);      // 42
const num2 = parseInt(str, 10); // 42
const num3 = +str;              // 42
console.log(num1, num2, num3); // 42 42 42
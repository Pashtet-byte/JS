// Задание 140: Default value через ||
let x140 = 0;
let y140 = x140 || 10;
console.log(y140); // 10
// Задание 176: Функция конфигурации
function configureApp(options = {}) {
  return {
    theme: options.theme ?? "light",
    debug: options.debug ?? false,
    timeout: options.timeout ?? 5000,
    retries: options.retries ?? 3
  };
}
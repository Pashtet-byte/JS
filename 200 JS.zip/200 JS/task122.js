// Задание 122: State machine
class StateMachine {
  constructor() {
    this.state = "idle";
  }
  
  transition(action) {
    switch(this.state) {
      case "idle":
        if (action === "start") this.state = "running";
        break;
      case "running":
        if (action === "stop") this.state = "stopped";
        if (action === "pause") this.state = "paused";
        break;
      case "paused":
        if (action === "resume") this.state = "running";
        if (action === "stop") this.state = "stopped";
        break;
    }
  }
}
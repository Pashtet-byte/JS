// Задание 98: Положительное/отрицательное/ноль
function sign(num) {
  if (num > 0) return "positive";
  if (num < 0) return "negative";
  return "zero";
}
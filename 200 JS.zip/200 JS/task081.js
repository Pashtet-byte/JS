// Задание 81: Компаратор для сортировки
const sortNumbers = (arr) => arr.sort((a, b) => a - b);
console.log(sortNumbers([3, 1, 4, 2])); // [1, 2, 3, 4]
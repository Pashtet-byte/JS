// Задание 43: Math.round
console.log(Math.round(4.5)); // 5
console.log(Math.round(4.4)); // 4
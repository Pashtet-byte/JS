// Задание 31: null + undefined
console.log(null + undefined); // NaN
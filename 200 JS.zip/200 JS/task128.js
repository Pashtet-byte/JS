// Задание 128: Функция when
function when(predicate, transform) {
  return (val) => predicate(val) ? transform(val) : val;
}
const doubleIfEven = when(x => x % 2 === 0, x => x * 2);
console.log(doubleIfEven(4)); // 8
console.log(doubleIfEven(5)); // 5
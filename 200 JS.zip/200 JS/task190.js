// Задание 190: Почему "nullish coalescing"
// Реагирует только на null и undefined (nullish), не на все falsy
// Задание 184: getDeep с ?? и optional chaining
function getDeepSafe(obj, path, defaultVal) {
  return path.split('.').reduce((o, k) => o?.[k], obj) ?? defaultVal;
}
console.log(getDeepSafe({a: {b: 42}}, 'a.b', 0)); // 42
console.log(getDeepSafe({}, 'a.b.c', 'default')); // "default"
// Задание 93: Компаратор для нескольких полей
function sortByFields(arr, fields) {
  return arr.sort((a, b) => {
    for (let field of fields) {
      if (a[field] < b[field]) return -1;
      if (a[field] > b[field]) return 1;
    }
    return 0;
  });
}
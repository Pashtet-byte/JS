// Задание 135: false || "default"
console.log(false || "default"); // "default"
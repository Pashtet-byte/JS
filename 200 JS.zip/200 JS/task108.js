// Задание 108: if("0")
if("0") console.log("true"); // true
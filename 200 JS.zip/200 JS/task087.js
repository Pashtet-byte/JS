// Задание 87: SameValueZero
// Используется в Set и Map: 0 === -0, NaN === NaN
console.log([NaN].includes(NaN)); // true
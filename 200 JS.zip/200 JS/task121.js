// Задание 121: Ленивые вычисления с тернарником
function expensiveA() { return 42; }
function expensiveB() { return 24; }
const condition121 = true;
const result121 = condition121 ? expensiveA() : expensiveB();
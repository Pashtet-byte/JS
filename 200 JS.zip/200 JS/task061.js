// Задание 61: Left shift
console.log(4 << 2); // 16 (4 * 2^2)
// Задание 91: Array.prototype.includes
console.log([1, 2, NaN].includes(NaN)); // true
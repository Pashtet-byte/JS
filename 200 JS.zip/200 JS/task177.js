// Задание 177: ||= vs ??=
let count177 = 0;
count177 ||= 10;
console.log(count177); // 10

let count178 = 0;
count178 ??= 10;
console.log(count178); // 0
// Задание 137: !!
console.log(!!"hello"); // true
console.log(!!0);       // false
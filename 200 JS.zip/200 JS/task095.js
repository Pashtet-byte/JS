// Задание 95: typeof null === "object"
console.log(typeof null === "object"); // true
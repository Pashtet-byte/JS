// Задание 23: 0.1 + 0.2 !== 0.3
console.log(0.1 + 0.2 === 0.3); // false
const epsilon = Number.EPSILON;
console.log(Math.abs(0.1 + 0.2 - 0.3) < epsilon); // true
// Задание 67: "5" == 5 и "5" === 5
console.log("5" == 5);  // true
console.log("5" === 5); // false
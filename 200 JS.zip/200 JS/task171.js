// Задание 171: ?? при деструктуризации
const obj171 = {name: null};
const {name = "Default"} = obj171;
const safeName = name ?? "Unknown";
console.log(safeName); // "Unknown"
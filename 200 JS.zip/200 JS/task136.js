// Задание 136: !
console.log(!true); // false
console.log(!0);    // true
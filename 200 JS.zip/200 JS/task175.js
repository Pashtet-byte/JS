// Задание 175: Optional chaining с ??
const user175 = null;
console.log(user175?.name ?? "Anonymous"); // "Anonymous"
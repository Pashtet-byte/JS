// Задание 160: Either паттерн
function either(success, error) {
  return {
    map: (fn) => success ? either(fn(success), error) : either(null, error),
    get: () => success ?? error
  };
}
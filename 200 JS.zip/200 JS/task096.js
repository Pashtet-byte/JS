// Задание 96: Proxy для логирования сравнений
const compareProxy = new Proxy({value: 42}, {
  get(target, prop) {
    if (prop === Symbol.toPrimitive) {
      return () => target.value;
    }
    return target[prop];
  }
});
console.log(compareProxy == 42); // true
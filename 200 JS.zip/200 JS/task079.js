// Задание 79: null > 0, null == 0, null >= 0
console.log(null > 0);   // false
console.log(null == 0);  // false
console.log(null >= 0);  // true
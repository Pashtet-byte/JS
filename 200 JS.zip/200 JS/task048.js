// Задание 48: Проверка на чётность
const isEven = n => n % 2 === 0;
console.log(isEven(4)); // true
console.log(isEven(5)); // false
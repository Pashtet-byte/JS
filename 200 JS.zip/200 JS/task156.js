// Задание 156: Optional chaining вручную
function getDeep(obj, path) {
  return path.split('.').reduce((o, p) => o && o[p], obj);
}
console.log(getDeep({a: {b: 42}}, 'a.b')); // 42
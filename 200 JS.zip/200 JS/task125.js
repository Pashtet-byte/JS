// Задание 125: Предикаты
const predicates = {
  isString: x => typeof x === "string",
  isNumber: x => typeof x === "number" && !isNaN(x),
  isArray: x => Array.isArray(x),
  isNull: x => x === null
};
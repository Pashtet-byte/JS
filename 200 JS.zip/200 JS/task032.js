// Задание 32: Функция определения типа (включая null)
function getType(val) {
  return val === null ? "null" : typeof val;
}
console.log(getType(null)); // "null"
console.log(getType([]));   // "object"
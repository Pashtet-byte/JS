// Задание 41: Случайное число от 1 до 10
function random1to10() {
  return Math.floor(Math.random() * 10) + 1;
}
console.log(random1to10());
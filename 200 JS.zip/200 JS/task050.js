// Задание 50: 1/0 и -1/0
console.log(1 / 0);  // Infinity
console.log(-1 / 0); // -Infinity
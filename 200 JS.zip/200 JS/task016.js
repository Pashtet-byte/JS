// Задание 16: null + 1 и undefined + 1
console.log(null + 1);      // 1
console.log(undefined + 1); // NaN
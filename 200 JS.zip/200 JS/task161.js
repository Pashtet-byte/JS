// Задание 161: De Morgan laws
// !(a && b) === !a || !b
// !(a || b) === !a && !b
function deMorgan(a, b) {
  return {
    left1: !(a && b),
    right1: !a || !b,
    left2: !(a || b),
    right2: !a && !b
  };
}
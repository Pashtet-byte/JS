// Задание 71: NaN === NaN
console.log(NaN === NaN); // false
console.log(Number.isNaN(NaN)); // true
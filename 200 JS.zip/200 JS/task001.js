// Задание 1: Что выведет console.log(typeof "hello")
console.log(typeof "hello"); // "string"
// Задание 111: Вложенный тернарник (сложный)
let x111 = 5;
let r111 = x111 > 3 ? (x111 > 7 ? "big" : "medium") : "small";
console.log(r111); // "medium"
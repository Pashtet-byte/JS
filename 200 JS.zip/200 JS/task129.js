// Задание 129: Декларативный роутер
const routes = {
  "/home": () => "Home Page",
  "/about": () => "About Page",
  "/contact": () => "Contact Page"
};
function router(path) {
  return routes[path]?.() ?? "404 Not Found";
}
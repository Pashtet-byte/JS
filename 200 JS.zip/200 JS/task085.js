// Задание 85: Symbol() == Symbol()
console.log(Symbol() == Symbol()); // false
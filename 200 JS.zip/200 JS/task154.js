// Задание 154: Lazy evaluation
function lazyAnd(a, b) {
  return a && b; // b не вычисляется если a falsy
}
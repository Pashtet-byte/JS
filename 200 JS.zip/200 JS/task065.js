// Задание 65: Количество цифр без String
function digitCount(n) {
  return Math.floor(Math.log10(Math.abs(n))) + 1;
}
console.log(digitCount(12345)); // 5
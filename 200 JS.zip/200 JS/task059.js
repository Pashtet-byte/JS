// Задание 59: НОД (алгоритм Евклида)
function gcd(a, b) {
  return b === 0 ? a : gcd(b, a % b);
}
console.log(gcd(48, 18)); // 6
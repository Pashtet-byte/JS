// Задание 186: deepMerge с ??
function deepMerge(defaults, options) {
  const result = {};
  for (let key in defaults) {
    if (typeof defaults[key] === 'object' && defaults[key] !== null) {
      result[key] = deepMerge(defaults[key], options[key] ?? {});
    } else {
      result[key] = options[key] ?? defaults[key];
    }
  }
  return result;
}
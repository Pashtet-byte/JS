// Задание 191: 0 || null ?? "x"
try {
  console.log(0 || null ?? "x");
} catch(e) {
  console.log("SyntaxError: need parentheses");
}
console.log((0 || null) ?? "x"); // "x"
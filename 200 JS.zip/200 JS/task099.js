// Задание 99: Тернарный оператор
const age = 20;
const status = age >= 18 ? "adult" : "minor";
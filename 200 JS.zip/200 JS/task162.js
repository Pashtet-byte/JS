// Задание 162: ?? vs ||
console.log(null ?? "default");    // "default"
console.log(undefined ?? "default"); // "default"
console.log(0 ?? "default");       // 0
console.log(0 || "default");       // "default"
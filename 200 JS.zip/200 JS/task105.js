// Задание 105: default в switch
function testSwitchDefault(val) {
  switch(val) {
    case 1: return "one";
    default: return "other";
  }
}
// Задание 181: ??= с объектом
let obj181 = {};
obj181.a ??= "set";
obj181.a ??= "again";
console.log(obj181.a); // "set"
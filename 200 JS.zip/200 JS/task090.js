// Задание 90: Локализованная сортировка строк
function sortStrings(arr) {
  return arr.sort((a, b) => a.localeCompare(b));
}
console.log(sortStrings(['éclair', 'apple', 'zoo']));
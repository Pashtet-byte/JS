document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай строку тремя разными способами.`;

document.getElementById('solutionCode').innerHTML = `const s1 = 'строка';\nconst s2 = "строка";\nconst s3 = \`строка\`;`;

document.getElementById('output').innerHTML = `Три способа: '', "", \`\``;
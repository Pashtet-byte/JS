document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Найди длину строки через свойство <code>length</code>.`;

document.getElementById('solutionCode').textContent = `const str = 'Привет';\nconsole.log(str.length); // 6`;

const str = 'Привет';
document.getElementById('output').innerHTML = `Длина строки 'Привет' = ${str.length}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Проверь тип значений: <code>[]</code>, <code>{}</code>, <code>Symbol("id")</code>, <code>10n</code>.`;

document.getElementById('solutionCode').innerHTML = `typeof [] → "object"\ntypeof {} → "object"\ntypeof Symbol("id") → "symbol"\ntypeof 10n → "bigint"`;

document.getElementById('output').innerHTML = `[]: ${typeof []}, {}: ${typeof {}}, Symbol(): ${typeof Symbol("id")}, 10n: ${typeof 10n}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй массив пар из <code>Object.entries()</code> в переменные через деструктуризацию в цикле.`;

document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2};\nfor (let [key, value] of Object.entries(obj)) console.log(key, value);`;

const obj = {a:1, b:2};
let out = '';
for (let [k,v] of Object.entries(obj)) out += `${k}:${v} `;
document.getElementById('output').innerHTML = out;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши код, который проверяет: является ли значение массивом, объектом, функцией или примитивом.`;

document.getElementById('solutionCode').textContent = `function getDetailedType(value) {\n  if (Array.isArray(value)) return 'array';\n  if (value && typeof value === 'object') return 'object';\n  if (typeof value === 'function') return 'function';\n  return typeof value;\n}`;

function getDetailedType(v) { if (Array.isArray(v)) return 'array'; if (v && typeof v === 'object') return 'object'; if (typeof v === 'function') return 'function'; return typeof v; }
document.getElementById('output').innerHTML = `[]: ${getDetailedType([])}, {}: ${getDetailedType({})}, () => {}: ${getDetailedType(() => {})}, 5: ${getDetailedType(5)}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем отличаются <code>find()</code> и <code>filter()</code>?`;

document.getElementById('solutionCode').innerHTML = `// find возвращает первый подходящий элемент (или undefined)\n// filter возвращает массив всех подходящих элементов`;

const arr = [1,2,3,4];
document.getElementById('output').innerHTML = `find(x=>x>2): ${arr.find(x=>x>2)}, filter(x=>x>2): ${arr.filter(x=>x>2)}`;
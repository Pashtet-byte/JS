document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Покажи разницу между примитивной строкой и объектом <code>new String("abc")</code>.`;

document.getElementById('solutionCode').innerHTML = `const prim = "abc";\nconst obj = new String("abc");\nconsole.log(typeof prim, typeof obj); // "string", "object"`;

const prim = "abc", obj = new String("abc");
document.getElementById('output').innerHTML = `prim: ${typeof prim}, obj: ${typeof obj}, prim == obj: ${prim == obj}, prim === obj: ${prim === obj}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое <code>WeakMap</code>? Чем он отличается от обычного <code>Map</code>?`;

document.getElementById('solutionCode').innerHTML = `// WeakMap: ключи только объекты, слабые ссылки, не итерируется, нет size\n// Не предотвращает сборку мусора ключей.`;

document.getElementById('output').innerHTML = `WeakMap для приватных данных и кэширования.`;
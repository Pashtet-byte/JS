document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй второй аргумент <code>JSON.stringify()</code> как функцию-replacer.`;

document.getElementById('solutionCode').textContent = `const obj = { a:1, b:2, c:3 };\nconst json = JSON.stringify(obj, (key, value) => value % 2 === 0 ? value : undefined); // только чётные`;

const obj = { a:1, b:2, c:3 };
const json = JSON.stringify(obj, (k,v) => v % 2 === 0 ? v : undefined);
document.getElementById('output').innerHTML = json;
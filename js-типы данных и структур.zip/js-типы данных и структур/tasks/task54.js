document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Удалить лишние пробелы в начале и конце строки, а потом заменить двойные пробелы на одинарные.`;

document.getElementById('solutionCode').textContent = `function cleanSpaces(str) {\n  return str.trim().replace(/\\s+/g, ' ');\n}`;

function cleanSpaces(s) { return s.trim().replace(/\s+/g, ' '); }
document.getElementById('output').innerHTML = `'${cleanSpaces('  hello   world  ')}'`;
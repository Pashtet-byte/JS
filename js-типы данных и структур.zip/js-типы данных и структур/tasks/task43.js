document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй калькулятор, который принимает строку с числами и операцией и аккуратно обрабатывает ошибки преобразования.`;

document.getElementById('solutionCode').textContent = `function calc(expr) {\n  try {\n    return Function('return ' + expr)();\n  } catch {\n    return NaN;\n  }\n}`;

function calc(expr) { try { return Function('return ' + expr)(); } catch { return NaN; } }
document.getElementById('output').innerHTML = `calc('2+2') = ${calc('2+2')}, calc('2/0') = ${calc('2/0')}`;
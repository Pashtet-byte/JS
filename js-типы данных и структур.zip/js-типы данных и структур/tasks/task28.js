document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое тип <code>number</code> в JavaScript? Какие числа он хранит?`;

document.getElementById('solutionCode').innerHTML = `// number — 64-битные числа с плавающей точкой (IEEE 754)\n// Хранит целые до 2^53, дробные, Infinity, -Infinity, NaN`;

document.getElementById('output').innerHTML = `number включает целые, дробные, бесконечности и NaN.`;
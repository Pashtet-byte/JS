document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая считает сумму всех числовых значений объекта через <code>Object.values()</code>.`;

document.getElementById('solutionCode').textContent = `function sumNumbers(obj) {\n  return Object.values(obj).filter(v => typeof v === 'number').reduce((s, v) => s + v, 0);\n}`;

function sumNumbers(obj) { return Object.values(obj).filter(v => typeof v === 'number').reduce((s, v) => s + v, 0); }
const obj = { a: 10, b: 'hello', c: 20, d: true };
document.getElementById('output').innerHTML = sumNumbers(obj);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Проверь работу <code>"hello".toUpperCase()</code> и объясни, что происходит "под капотом".`;

document.getElementById('solutionCode').innerHTML = `// Создаётся временный объект String("hello"), вызывается его метод, затем объект уничтожается.`;

document.getElementById('output').innerHTML = `"hello".toUpperCase() = ${"hello".toUpperCase()}`;
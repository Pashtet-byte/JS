document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй собственный аналог метода <code>filter()</code> под названием <code>myFilter()</code>.`;

document.getElementById('solutionCode').textContent = `function myFilter(arr, fn) {\n  const result = [];\n  for (let i = 0; i < arr.length; i++) {\n    if (fn(arr[i], i, arr)) result.push(arr[i]);\n  }\n  return result;\n}`;

function myFilter(arr, fn) { const r=[]; for(let i=0; i<arr.length; i++) if(fn(arr[i],i,arr)) r.push(arr[i]); return r; }
document.getElementById('output').innerHTML = myFilter([1,2,3,4], x => x%2===0);
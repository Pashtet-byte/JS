document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>flat()</code> и <code>flatMap()</code> на небольших примерах.`;

document.getElementById('solutionCode').textContent = `const arr = [1,[2,3],4];\nconsole.log(arr.flat()); // [1,2,3,4]\nconst words = ['hello world', 'good morning'];\nconsole.log(words.flatMap(w => w.split(' '))); // ['hello','world','good','morning']`;

const arr = [1,[2,3],4];
const words = ['hello world', 'good morning'];
document.getElementById('output').innerHTML = `flat: ${arr.flat()}, flatMap: ${words.flatMap(w => w.split(' '))}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию <code>chunk(arr, size)</code>, разбивающую массив на части.`;

document.getElementById('solutionCode').textContent = `function chunk(arr, size) {\n  const result = [];\n  for (let i = 0; i < arr.length; i += size) {\n    result.push(arr.slice(i, i + size));\n  }\n  return result;\n}`;

function chunk(arr, size) { const r=[]; for (let i=0; i<arr.length; i+=size) r.push(arr.slice(i,i+size)); return r; }
document.getElementById('output').innerHTML = JSON.stringify(chunk([1,2,3,4,5,6,7], 3));
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Найди результат выражения <code>0.1 + 0.2</code> и объясни особенность.`;

document.getElementById('solutionCode').innerHTML = `console.log(0.1 + 0.2); // 0.30000000000000004\n// Из-за погрешности двоичного представления дробей.`;

document.getElementById('output').innerHTML = `0.1 + 0.2 = ${0.1 + 0.2}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Найди индекс элемента через <code>indexOf()</code> и <code>includes()</code>.`;

document.getElementById('solutionCode').textContent = `const arr = [10,20,30];\nconsole.log(arr.indexOf(20)); // 1\nconsole.log(arr.includes(20)); // true`;

const arr = [10,20,30];
document.getElementById('output').innerHTML = `indexOf(20): ${arr.indexOf(20)}, includes(20): ${arr.includes(20)}`;
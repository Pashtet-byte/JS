document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое timestamp? Получи его через <code>Date.now()</code>.`;

document.getElementById('solutionCode').textContent = `const timestamp = Date.now();`;

document.getElementById('output').innerHTML = Date.now();
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое <code>BigInt</code>? Приведи пример создания большого целого числа.`;

document.getElementById('solutionCode').innerHTML = `// BigInt — для целых чисел произвольной длины.\nconst big = 123456789012345678901234567890n;\nconst alsoBig = BigInt(9007199254740991);`;

const big = 123456789012345678901234567890n;
document.getElementById('output').innerHTML = `Пример: ${big.toString().slice(0,20)}...`;
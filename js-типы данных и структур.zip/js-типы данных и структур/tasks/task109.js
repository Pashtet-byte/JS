document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>В чём отличие <code>Map</code> от обычного объекта?`;

document.getElementById('solutionCode').innerHTML = `// Map: ключи любого типа, сохраняет порядок вставки, size, методы set/get/delete/has\n// Объект: ключи только строки и символы, не гарантирует порядок (ES6 гарантирует)`;

document.getElementById('output').innerHTML = `Map гибче для частого добавления/удаления и ключей-объектов.`;
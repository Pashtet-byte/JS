document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай деструктуризацию массива <code>[1,2,3]</code> в переменные <code>a</code>, <code>b</code>, <code>c</code>.`;

document.getElementById('solutionCode').textContent = `const [a,b,c] = [1,2,3];`;

const [a,b,c] = [1,2,3];
document.getElementById('output').innerHTML = `a=${a}, b=${b}, c=${c}`;
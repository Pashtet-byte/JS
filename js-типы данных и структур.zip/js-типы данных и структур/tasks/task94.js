document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй собственный аналог метода <code>reduce()</code> под названием <code>myReduce()</code>.`;

document.getElementById('solutionCode').textContent = `function myReduce(arr, fn, init) {\n  let acc = init;\n  for (let i = 0; i < arr.length; i++) {\n    acc = fn(acc, arr[i], i, arr);\n  }\n  return acc;\n}`;

function myReduce(arr, fn, init) { let a = init; for(let i=0; i<arr.length; i++) a = fn(a, arr[i], i, arr); return a; }
document.getElementById('output').innerHTML = myReduce([1,2,3,4], (s,x) => s+x, 0);
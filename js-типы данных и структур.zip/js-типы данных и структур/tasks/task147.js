document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай деструктуризацию объекта <code>{name:"Ann", age:20}</code>.`;

document.getElementById('solutionCode').textContent = `const {name, age} = {name:"Ann", age:20};`;

const {name, age} = {name:"Ann", age:20};
document.getElementById('output').innerHTML = `name=${name}, age=${age}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сериализуй <code>Set</code> вручную в JSON и потом восстанови его.`;

document.getElementById('solutionCode').textContent = `const set = new Set([1,2,3]);\nconst json = JSON.stringify([...set]);\nconst restored = new Set(JSON.parse(json));`;

const set = new Set([1,2,3]);
const json = JSON.stringify([...set]);
const restored = new Set(JSON.parse(json));
document.getElementById('output').innerHTML = JSON.stringify([...restored]);
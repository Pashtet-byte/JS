document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему у <code>WeakMap</code> и <code>WeakSet</code> нет перебора через <code>for...of</code>?`;

document.getElementById('solutionCode').innerHTML = `// Поскольку ссылки слабые, они могут быть удалены во время итерации.\n// Нельзя гарантировать консистентность.`;

document.getElementById('output').innerHTML = `Нет методов перебора из-за неопределённости существования.`;
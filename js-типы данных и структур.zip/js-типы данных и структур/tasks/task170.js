document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>formatDate(date)</code> в формате <code>DD.MM.YYYY</code>.`;

document.getElementById('solutionCode').textContent = `function formatDate(date) {\n  const d = date.getDate().toString().padStart(2,'0');\n  const m = (date.getMonth()+1).toString().padStart(2,'0');\n  const y = date.getFullYear();\n  return \`\${d}.\${m}.\${y}\`;\n}`;

function formatDate(date) { const d=date.getDate().toString().padStart(2,'0'); const m=(date.getMonth()+1).toString().padStart(2,'0'); const y=date.getFullYear(); return `${d}.${m}.${y}`; }
document.getElementById('output').innerHTML = formatDate(new Date());
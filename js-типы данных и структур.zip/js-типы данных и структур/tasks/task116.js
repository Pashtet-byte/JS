document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй <code>Map</code> обратно в обычный объект.`;

document.getElementById('solutionCode').textContent = `const map = new Map([['a',1], ['b',2]]);\nconst obj = Object.fromEntries(map);`;

const map = new Map([['a',1], ['b',2]]);
const obj = Object.fromEntries(map);
document.getElementById('output').innerHTML = JSON.stringify(obj);
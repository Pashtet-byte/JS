document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Перебери объект через <code>Object.entries()</code> и <code>for...of</code>.`;

document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2};\nfor (let [key, val] of Object.entries(obj)) console.log(key, val);`;

const obj = {a:1, b:2};
let out = '';
for (let [k,v] of Object.entries(obj)) out += `${k}:${v} `;
document.getElementById('output').innerHTML = out;
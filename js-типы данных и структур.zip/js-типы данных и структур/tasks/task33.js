document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как получить случайное целое число от 1 до 10?`;

document.getElementById('solutionCode').textContent = `const random = Math.floor(Math.random() * 10) + 1;`;

const random = Math.floor(Math.random() * 10) + 1;
document.getElementById('output').innerHTML = `Случайное: ${random}`;
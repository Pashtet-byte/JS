document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>WeakSet</code> для хранения набора уже обработанных объектов.`;

document.getElementById('solutionCode').textContent = `const processed = new WeakSet();\n\nfunction process(obj) {\n  if (processed.has(obj)) return;\n  processed.add(obj);\n  // обработать\n}`;

const processed = new WeakSet();
const obj = {};
processed.add(obj);
document.getElementById('output').innerHTML = `processed.has(obj): ${processed.has(obj)}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем отличаются <code>slice()</code>, <code>substring()</code> и <code>substr()</code>? Проверь на примерах.`;

document.getElementById('solutionCode').innerHTML = `// slice(start, end) — от start до end-1\n// substring(start, end) — аналогично, но start > end меняются\n// substr(start, length) — от start заданное количество символов`;

const str = 'Hello World';
document.getElementById('output').innerHTML = `slice(0,5): ${str.slice(0,5)}, substring(6,11): ${str.substring(6,11)}, substr(6,5): ${str.substr(6,5)}`;ы
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай массив через <code>Array.from()</code> из строки и из объекта с <code>length</code>.`;

document.getElementById('solutionCode').textContent = `Array.from('hello'); // ['h','e','l','l','o']\nArray.from({length:3}, (_,i) => i); // [0,1,2]`;

document.getElementById('output').innerHTML = `из строки: ${Array.from('hello')}, из length: ${Array.from({length:3}, (_,i)=>i)}`;
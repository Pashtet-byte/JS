document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши цепочку методов массива: фильтрация, преобразование, сортировка.`;

document.getElementById('solutionCode').textContent = `const arr = [1,2,3,4,5,6];\nconst result = arr\n  .filter(x => x % 2 === 0)\n  .map(x => x * 10)\n  .sort((a,b) => b - a);`;

const arr = [1,2,3,4,5,6];
const result = arr.filter(x => x%2===0).map(x=>x*10).sort((a,b)=>b-a);
document.getElementById('output').innerHTML = result;
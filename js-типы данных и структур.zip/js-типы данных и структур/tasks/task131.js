document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Объясни, как <code>WeakMap</code> помогает избегать утечек памяти.`;

document.getElementById('solutionCode').innerHTML = `// Если ключ-объект удаляется из всех остальных мест, он также удаляется из WeakMap,\n// так как ссылка слабая. В Map он бы остался и мешал сборке мусора.`;

document.getElementById('output').innerHTML = `WeakMap не удерживает объекты от сборки мусора.`;
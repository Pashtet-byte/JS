document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как получить первый, последний и предпоследний элемент массива?`;

document.getElementById('solutionCode').textContent = `const arr = [10,20,30,40];\nconst first = arr[0];\nconst last = arr[arr.length-1];\nconst secondLast = arr[arr.length-2];`;

const arr = [10,20,30,40];
document.getElementById('output').innerHTML = `first: ${arr[0]}, last: ${arr[arr.length-1]}, предпоследний: ${arr[arr.length-2]}`;
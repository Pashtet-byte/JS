document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию глубокой фильтрации объекта, используя рекурсию и <code>Object.entries()</code>.`;

document.getElementById('solutionCode').textContent = `function deepFilter(obj, predicate) {\n  return Object.fromEntries(\n    Object.entries(obj)\n      .map(([k, v]) => [k, v && typeof v === 'object' ? deepFilter(v, predicate) : v])\n      .filter(([k, v]) => predicate(v))\n  );\n}`;

function deepFilter(obj, p) { return Object.fromEntries(Object.entries(obj).map(([k,v]) => [k, v && typeof v==='object' ? deepFilter(v,p) : v]).filter(([k,v]) => p(v))); }
const obj = { a:1, b:2, c:{ d:3, e:4 } };
const filtered = deepFilter(obj, x => x > 2);
document.getElementById('output').innerHTML = JSON.stringify(filtered);
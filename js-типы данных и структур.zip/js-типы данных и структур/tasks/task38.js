document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>toString(2)</code>, чтобы перевести число в двоичную запись.`;

document.getElementById('solutionCode').textContent = `const num = 42;\nconsole.log(num.toString(2)); // "101010"`;

const num = 42;
document.getElementById('output').innerHTML = `42 в двоичной: ${num.toString(2)}`;
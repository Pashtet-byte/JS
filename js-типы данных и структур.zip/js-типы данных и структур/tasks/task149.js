document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как задать значения по умолчанию в деструктуризации массива и объекта?`;

document.getElementById('solutionCode').textContent = `const [a=1] = []; // a=1\nconst {b=2} = {}; // b=2`;

const [a=1] = [];
const {b=2} = {};
document.getElementById('output').innerHTML = `a=${a}, b=${b}`;
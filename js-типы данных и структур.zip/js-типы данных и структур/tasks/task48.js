document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Получить первый и последний символ строки.`;

document.getElementById('solutionCode').textContent = `const str = 'JavaScript';\nconst first = str[0];\nconst last = str[str.length - 1];`;

const str = 'JavaScript';
document.getElementById('output').innerHTML = `первый: ${str[0]}, последний: ${str[str.length-1]}`;
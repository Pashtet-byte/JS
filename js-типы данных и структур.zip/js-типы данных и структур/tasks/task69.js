document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Объедини два массива через <code>concat()</code> и через spread.`;

document.getElementById('solutionCode').textContent = `const a = [1,2], b = [3,4];\nconst c = a.concat(b);\nconst d = [...a, ...b];`;

const a = [1,2], b = [3,4];
document.getElementById('output').innerHTML = `concat: ${a.concat(b)}, spread: ${[...a,...b]}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему функция в JavaScript тоже считается объектом? Покажи это на примере свойств функции.`;

document.getElementById('solutionCode').textContent = `function foo() {}\nfoo.bar = 42;\nconsole.log(foo.bar); // 42\n// У функции есть свойства и методы, как у объекта.`;

function foo() {} foo.bar = 42;
document.getElementById('output').innerHTML = `foo.bar = ${foo.bar}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем примитивы отличаются от объектов?`;

document.getElementById('solutionCode').innerHTML = `// Примитивы хранятся по значению, объекты — по ссылке.\n// Примитивы иммутабельны, объекты могут изменяться.`;

document.getElementById('output').innerHTML = `Примитивы — значения, объекты — ссылки.`;
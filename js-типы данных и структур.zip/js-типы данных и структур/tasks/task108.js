document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай <code>Map</code> с тремя парами ключ-значение.`;

document.getElementById('solutionCode').textContent = `const map = new Map([['a',1], ['b',2], ['c',3]]);`;

const map = new Map([['a',1], ['b',2], ['c',3]]);
document.getElementById('output').innerHTML = JSON.stringify([...map]);
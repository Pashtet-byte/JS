document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как переименовать переменную при деструктуризации объекта?`;

document.getElementById('solutionCode').textContent = `const {name: userName} = {name:"Ann"}; // userName = "Ann"`;

const {name: userName} = {name:"Ann"};
document.getElementById('output').innerHTML = `userName=${userName}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое <code>Infinity</code> и <code>-Infinity</code>? Приведи примеры получения.`;

document.getElementById('solutionCode').innerHTML = `// Положительная и отрицательная бесконечность\n1 / 0 → Infinity\n-1 / 0 → -Infinity`;

document.getElementById('output').innerHTML = `1/0 = ${1/0}, -1/0 = ${-1/0}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Установи у даты новый год, месяц и день через сеттеры.`;

document.getElementById('solutionCode').textContent = `const d = new Date();\nd.setFullYear(2025);\nd.setMonth(11); // декабрь\nd.setDate(25);`;

const d = new Date();
d.setFullYear(2025);
d.setMonth(11);
d.setDate(25);
document.getElementById('output').innerHTML = d.toDateString();
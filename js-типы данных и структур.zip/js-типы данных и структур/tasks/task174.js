document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>toISOString()</code> и объясни формат результата.`;

document.getElementById('solutionCode').textContent = `const d = new Date();\nconsole.log(d.toISOString()); // YYYY-MM-DDTHH:mm:ss.sssZ`;

document.getElementById('output').innerHTML = new Date().toISOString();
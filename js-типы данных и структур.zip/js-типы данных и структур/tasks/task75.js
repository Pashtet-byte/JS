document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>flattenOneLevel(arr)</code>, которая разворачивает массив только на один уровень.`;

document.getElementById('solutionCode').textContent = `function flattenOneLevel(arr) {\n  return [].concat(...arr);\n}`;

function flattenOneLevel(arr) { return [].concat(...arr); }
document.getElementById('output').innerHTML = flattenOneLevel([[1,2],[3,4]]);
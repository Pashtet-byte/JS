document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая возвращает номер недели месяца для заданной даты.`;

document.getElementById('solutionCode').textContent = `function weekOfMonth(date) {\n  const first = new Date(date.getFullYear(), date.getMonth(), 1);\n  const offset = first.getDay();\n  return Math.ceil((date.getDate() + offset) / 7);\n}`;

function weekOfMonth(d) { const first = new Date(d.getFullYear(), d.getMonth(), 1); const off = first.getDay(); return Math.ceil((d.getDate() + off) / 7); }
document.getElementById('output').innerHTML = weekOfMonth(new Date());
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое <code>WeakSet</code>? Чем он отличается от обычного <code>Set</code>?`;

document.getElementById('solutionCode').innerHTML = `// WeakSet хранит только объекты, слабые ссылки, не итерируется, нет size\n// Не предотвращает сборку мусора.`;

document.getElementById('output').innerHTML = `WeakSet для маркировки объектов без утечек.`;
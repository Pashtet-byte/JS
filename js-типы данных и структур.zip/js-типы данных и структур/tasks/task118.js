document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши пересечение двух массивов через <code>Set</code>.`;

document.getElementById('solutionCode').textContent = `function intersection(arr1, arr2) {\n  const set2 = new Set(arr2);\n  return arr1.filter(x => set2.has(x));\n}`;

function intersection(a1, a2) { const s2 = new Set(a2); return a1.filter(x => s2.has(x)); }
document.getElementById('output').innerHTML = intersection([1,2,3,4], [3,4,5,6]);
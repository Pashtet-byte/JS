document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй третий аргумент <code>JSON.stringify()</code> для красивого форматирования.`;

document.getElementById('solutionCode').textContent = `const obj = { a:1, b:2, c:3 };\nconsole.log(JSON.stringify(obj, null, 2));`;

const obj = { a:1, b:2, c:3 };
document.getElementById('output').innerHTML = JSON.stringify(obj, null, 2).replace(/\n/g, '<br>');
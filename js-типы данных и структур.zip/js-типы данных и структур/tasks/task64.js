document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Удали элементы из конца и начала массива через <code>pop()</code> и <code>shift()</code>.`;

document.getElementById('solutionCode').textContent = `const arr = [1,2,3,4];\narr.pop();    // [1,2,3]\narr.shift(); // [2,3]`;

const arr = [1,2,3,4]; arr.pop(); arr.shift();
document.getElementById('output').innerHTML = `[${arr}]`;
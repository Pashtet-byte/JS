document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>getType(value)</code>, которая корректно определяет <code>null</code> отдельно от объекта.`;

document.getElementById('solutionCode').textContent = `function getType(value) {\n  if (value === null) return 'null';\n  return typeof value;\n}`;

function getType(value) { if (value === null) return 'null'; return typeof value; }
document.getElementById('output').innerHTML = `getType(null) = ${getType(null)}, getType({}) = ${getType({})}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>filter()</code>, чтобы оставить только чётные числа.`;

document.getElementById('solutionCode').textContent = `[1,2,3,4,5].filter(x => x % 2 === 0);`;

document.getElementById('output').innerHTML = [1,2,3,4,5].filter(x => x % 2 === 0);
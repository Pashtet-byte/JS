document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое <code>NaN</code>? Как проверить, что значение — именно <code>NaN</code>?`;

document.getElementById('solutionCode').innerHTML = `// NaN = Not a Number\n// Проверка: Number.isNaN(value) или value !== value (только NaN не равен сам себе)`;

const n = NaN;
document.getElementById('output').innerHTML = `Number.isNaN(NaN): ${Number.isNaN(NaN)}, NaN === NaN: ${NaN === NaN}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Получить год, месяц, день, часы, минуты и секунды из даты.`;

document.getElementById('solutionCode').textContent = `const d = new Date();\nconst year = d.getFullYear();\nconst month = d.getMonth();\nconst day = d.getDate();\nconst hours = d.getHours();\nconst minutes = d.getMinutes();\nconst seconds = d.getSeconds();`;

const d = new Date();
document.getElementById('output').innerHTML = `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${d.getHours()}:${d.getMinutes()}:${d.getSeconds()}`;
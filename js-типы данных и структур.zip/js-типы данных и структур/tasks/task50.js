document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>includes()</code>, <code>startsWith()</code> и <code>endsWith()</code> для одной строки.`;

document.getElementById('solutionCode').textContent = `const str = 'JavaScript';\nconsole.log(str.includes('Script')); // true\nconsole.log(str.startsWith('Java')); // true\nconsole.log(str.endsWith('Script')); // true`;

const str = 'JavaScript';
document.getElementById('output').innerHTML = `includes: ${str.includes('Script')}, startsWith: ${str.startsWith('Java')}, endsWith: ${str.endsWith('Script')}`;
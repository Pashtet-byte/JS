document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>unique(arr)</code>, которая удаляет дубликаты без использования <code>Set</code>.`;

document.getElementById('solutionCode').textContent = `function unique(arr) {\n  return arr.filter((v, i, a) => a.indexOf(v) === i);\n}`;

function unique(arr) { return arr.filter((v,i,a) => a.indexOf(v) === i); }
document.getElementById('output').innerHTML = `unique([1,2,2,3]) = ${unique([1,2,2,3])}`;
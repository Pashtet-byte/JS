document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем отличаются <code>parseInt</code> и <code>parseFloat</code>?`;

document.getElementById('solutionCode').innerHTML = `// parseInt извлекает целое число из строки\n// parseFloat извлекает число с плавающей точкой`;

document.getElementById('output').innerHTML = `parseInt("10.5px") = ${parseInt("10.5px")}, parseFloat("10.5px") = ${parseFloat("10.5px")}`;
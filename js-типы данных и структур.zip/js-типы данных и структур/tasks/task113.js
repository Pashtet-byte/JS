document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как получить размер <code>Map</code> и <code>Set</code>?`;

document.getElementById('solutionCode').innerHTML = `// map.size, set.size`;

const map = new Map([['a',1]]);
const set = new Set([1,2]);
document.getElementById('output').innerHTML = `map.size: ${map.size}, set.size: ${set.size}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй объект цен в массив строк вида <code>"apple: 100"</code> через <code>Object.entries()</code>.`;

document.getElementById('solutionCode').textContent = `const prices = { apple: 100, banana: 50, orange: 70 };\nconst strings = Object.entries(prices).map(([item, price]) => \`\${item}: \${price}\`);`;

const prices = { apple: 100, banana: 50, orange: 70 };
const strings = Object.entries(prices).map(([i, p]) => `${i}: ${p}`);
document.getElementById('output').innerHTML = strings;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>forEach()</code>, чтобы вывести каждый элемент массива.`;

document.getElementById('solutionCode').textContent = `[1,2,3].forEach(x => console.log(x));`;

let out = '';
[1,2,3].forEach(x => out += x + ' ');
document.getElementById('output').innerHTML = out;
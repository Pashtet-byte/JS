document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Скопируй массив разными способами и проверь, что копия не равна исходнику по ссылке.`;

document.getElementById('solutionCode').textContent = `const orig = [1,2,3];\nconst copy1 = orig.slice();\nconst copy2 = [...orig];\nconst copy3 = Array.from(orig);\nconsole.log(copy1 === orig); // false`;

const orig = [1,2,3];
const copy = [...orig];
document.getElementById('output').innerHTML = `copy === orig: ${copy === orig}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию округления числа до двух знаков после запятой.`;

document.getElementById('solutionCode').textContent = `function round2(value) {\n  return Math.round(value * 100) / 100;\n}`;

function round2(v) { return Math.round(v * 100) / 100; }
document.getElementById('output').innerHTML = `round2(5.6789) = ${round2(5.6789)}`;
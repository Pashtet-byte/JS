document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй собственный аналог метода <code>map()</code> под названием <code>myMap()</code>.`;

document.getElementById('solutionCode').textContent = `function myMap(arr, fn) {\n  const result = [];\n  for (let i = 0; i < arr.length; i++) result.push(fn(arr[i], i, arr));\n  return result;\n}`;

function myMap(arr, fn) { const r=[]; for(let i=0; i<arr.length; i++) r.push(fn(arr[i], i, arr)); return r; }
document.getElementById('output').innerHTML = myMap([1,2,3], x => x*2);
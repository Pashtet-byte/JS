document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему у <code>null</code> и <code>undefined</code> нельзя вызывать методы?`;

document.getElementById('solutionCode').innerHTML = `// У них нет объектов-обёрток. При попытке доступа к свойству возникает ошибка.`;

document.getElementById('output').innerHTML = `null?.toString → undefined (без ошибки), но null.toString() — ошибка`;
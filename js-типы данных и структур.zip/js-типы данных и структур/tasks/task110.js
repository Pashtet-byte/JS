document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Добавь, получи, проверь и удали значение в <code>Map</code>.`;

document.getElementById('solutionCode').textContent = `const map = new Map();\nmap.set('key', 'value');\nmap.get('key'); // 'value'\nmap.has('key'); // true\nmap.delete('key'); // true`;

const map = new Map(); map.set('key','value');
document.getElementById('output').innerHTML = `has: ${map.has('key')}, get: ${map.get('key')}, delete: ${map.delete('key')}, has again: ${map.has('key')}`;
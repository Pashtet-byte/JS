document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая показывает сколько минут прошло с заданного момента.`;

document.getElementById('solutionCode').textContent = `function minutesSince(date) {\n  return Math.floor((Date.now() - date) / (1000 * 60));\n}`;

const past = new Date(Date.now() - 3600000);
document.getElementById('output').innerHTML = `прошло ${Math.floor((Date.now() - past) / 60000)} минут`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй строку в массив символов через итерирование.`;

document.getElementById('solutionCode').textContent = `const str = 'abc';\nconst arr = [...str];\n// или Array.from(str)`;

document.getElementById('output').innerHTML = [...'abc'];
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй деструктуризацию с итерируемым объектом, который не является массивом.`;

document.getElementById('solutionCode').textContent = `const set = new Set([1,2,3]);\nconst [a,b,c] = set; // a=1,b=2,c=3`;

const set = new Set([1,2,3]);
const [a,b,c] = set;
document.getElementById('output').innerHTML = `a=${a}, b=${b}, c=${c}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>Set</code>, чтобы убрать дубликаты из массива.`;

document.getElementById('solutionCode').textContent = `const arr = [1,2,2,3,3,4];\nconst unique = [...new Set(arr)];`;

const arr = [1,2,2,3,3,4];
const unique = [...new Set(arr)];
document.getElementById('output').innerHTML = unique;
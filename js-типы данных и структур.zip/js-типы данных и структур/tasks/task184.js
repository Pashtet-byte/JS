document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй JSON-строку обратно в объект через <code>JSON.parse()</code>.`;

document.getElementById('solutionCode').textContent = `const json = '{"name":"Иван","age":30}';\nconst obj = JSON.parse(json);`;

const json = '{"name":"Иван","age":30}';
const obj = JSON.parse(json);
document.getElementById('output').innerHTML = JSON.stringify(obj);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй дату в строку через <code>toString()</code>, <code>toDateString()</code>, <code>toTimeString()</code>.`;

document.getElementById('solutionCode').textContent = `const d = new Date();\nconsole.log(d.toString());\nconsole.log(d.toDateString());\nconsole.log(d.toTimeString());`;

const d = new Date();
document.getElementById('output').innerHTML = `${d.toString()}<br>${d.toDateString()}<br>${d.toTimeString()}`;
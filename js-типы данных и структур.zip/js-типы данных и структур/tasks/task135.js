document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>Object.values()</code> для получения всех значений объекта.`;

document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2, c:3};\nconsole.log(Object.values(obj)); // [1,2,3]`;

const obj = {a:1, b:2, c:3};
document.getElementById('output').innerHTML = Object.values(obj);
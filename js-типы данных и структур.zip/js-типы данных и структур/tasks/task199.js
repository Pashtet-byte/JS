document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай функцию <code>saveState(obj)</code> и <code>loadState(json)</code> для сохранения и восстановления состояния приложения.`;

document.getElementById('solutionCode').textContent = `function saveState(obj) {\n  return JSON.stringify(obj);\n}\nfunction loadState(json) {\n  return JSON.parse(json);\n}`;

function saveState(obj) { return JSON.stringify(obj); }
function loadState(json) { return JSON.parse(json); }
const state = { user: 'Иван', score: 100 };
const saved = saveState(state);
const loaded = loadState(saved);
document.getElementById('output').innerHTML = `загружено: ${JSON.stringify(loaded)}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Объясни, почему циклические ссылки ломают <code>JSON.stringify()</code>.`;

document.getElementById('solutionCode').textContent = `const obj = {};\nobj.self = obj;\nJSON.stringify(obj); // TypeError: Converting circular structure to JSON`;

const obj = {}; obj.self = obj;
document.getElementById('output').innerHTML = `циклическая ссылка вызывает ошибку`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая группирует элементы массива по какому-либо критерию через <code>reduce()</code>.`;

document.getElementById('solutionCode').textContent = `function groupBy(arr, keyFn) {\n  return arr.reduce((acc, item) => {\n    const key = keyFn(item);\n    acc[key] = acc[key] || [];\n    acc[key].push(item);\n    return acc;\n  }, {});\n}`;

function groupBy(arr, fn) { return arr.reduce((a, it) => { const k = fn(it); a[k] = a[k] || []; a[k].push(it); return a; }, {}); }
const grouped = groupBy([{type:'a'},{type:'b'},{type:'a'}], x => x.type);
document.getElementById('output').innerHTML = JSON.stringify(grouped);
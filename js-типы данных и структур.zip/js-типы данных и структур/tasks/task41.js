document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Объясни, почему <code>9007199254740991</code> — особое число в JavaScript.`;

document.getElementById('solutionCode').innerHTML = `// Это Number.MAX_SAFE_INTEGER — максимальное целое, которое можно безопасно представить в 64-битном формате.`;

document.getElementById('output').innerHTML = `MAX_SAFE_INTEGER = ${Number.MAX_SAFE_INTEGER}`;
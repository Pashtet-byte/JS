document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай мини-парсер строки запроса вида <code>"name=Ivan&age=20"</code> в объект.`;

document.getElementById('solutionCode').textContent = `function parseQuery(str) {\n  return Object.fromEntries(str.split('&').map(p => p.split('=')));\n}`;

function parseQuery(s) { return Object.fromEntries(s.split('&').map(p => p.split('='))); }
document.getElementById('output').innerHTML = JSON.stringify(parseQuery('name=Ivan&age=20'));
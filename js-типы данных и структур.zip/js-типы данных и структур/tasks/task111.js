document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай <code>Set</code> и добавь в него несколько значений, включая дубликаты.`;

document.getElementById('solutionCode').textContent = `const set = new Set([1,2,2,3,3,4]); // Set {1,2,3,4}`;

const set = new Set([1,2,2,3,3,4]);
document.getElementById('output').innerHTML = [...set];
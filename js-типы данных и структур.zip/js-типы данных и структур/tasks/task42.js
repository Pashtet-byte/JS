document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Покажи, как использовать <code>BigInt</code> в арифметике и почему его нельзя смешивать с <code>number</code> без явного преобразования.`;

document.getElementById('solutionCode').innerHTML = `const big = 10n;\n// big + 5 → ошибка\nbig + 5n → 15n`;

const big = 10n;
document.getElementById('output').innerHTML = `big + 5n = ${String(big + 5n)}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй кеш результатов функции через <code>Map</code>.`;

document.getElementById('solutionCode').textContent = `function memoize(fn) {\n  const cache = new Map();\n  return function(arg) {\n    if (cache.has(arg)) return cache.get(arg);\n    const result = fn(arg);\n    cache.set(arg, result);\n    return result;\n  };\n}`;

function memoize(fn) { const c = new Map(); return arg => { if (c.has(arg)) return c.get(arg); const r = fn(arg); c.set(arg, r); return r; }; }
const double = x => x*2;
const memDouble = memoize(double);
document.getElementById('output').innerHTML = `memDouble(5)=${memDouble(5)} (закешировано)`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему у примитивов можно вызывать методы, если они не являются объектами?`;

document.getElementById('solutionCode').innerHTML = `// При вызове метода примитив временно оборачивается в объект-обёртку (String, Number, Boolean).`;

document.getElementById('output').innerHTML = `"hello".toUpperCase() → ${"hello".toUpperCase()}`;
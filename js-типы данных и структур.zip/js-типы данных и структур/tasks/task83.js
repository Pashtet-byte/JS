document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему для сортировки чисел нужно передавать колбэк в <code>sort()</code>? Покажи на примере.`;

document.getElementById('solutionCode').innerHTML = `// sort() сортирует строки лексикографически: [1,10,2] → [1,10,2]\n// Для чисел нужен колбэк: [1,10,2].sort((a,b) => a-b) → [1,2,10]`;

document.getElementById('output').innerHTML = `без колбэка: ${[1,10,2].sort()}, с колбэком: ${[1,10,2].sort((a,b)=>a-b)}`;
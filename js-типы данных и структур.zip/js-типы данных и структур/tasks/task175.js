document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию проверки: является ли дата выходным днём.`;

document.getElementById('solutionCode').textContent = `function isWeekend(date) {\n  const day = date.getDay();\n  return day === 0 || day === 6;\n}`;

function isWeekend(d) { const day = d.getDay(); return day === 0 || day === 6; }
document.getElementById('output').innerHTML = isWeekend(new Date());
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая экранирует спецсимволы HTML в строке.`;

document.getElementById('solutionCode').textContent = `function escapeHTML(str) {\n  return str.replace(/[&<>"]/g, (m) => ({\n    '&': '&amp;',\n    '<': '&lt;',\n    '>': '&gt;',\n    '"': '&quot;'\n  })[m]);\n}`;

function escapeHTML(s) { return s.replace(/[&<>"]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[m]); }
document.getElementById('output').innerHTML = escapeHTML('<div class="test">');
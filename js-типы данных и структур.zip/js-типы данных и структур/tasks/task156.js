document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, принимающую массив координат и сразу деструктурирующую их в параметрах.`;

document.getElementById('solutionCode').textContent = `function move([x, y]) {\n  return \`Перемещение на (\${x}, \${y})\`;\n}\nmove([5, 10]);`;

function move([x,y]) { return `Перемещение на (${x}, ${y})`; }
document.getElementById('output').innerHTML = move([5,10]);
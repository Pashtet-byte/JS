document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Покажи, как <code>toJSON()</code> меняет результат сериализации объекта.`;

document.getElementById('solutionCode').textContent = `const point = { x:10, y:20, toJSON() { return [this.x, this.y]; } };\nconsole.log(JSON.stringify(point)); // [10,20]`;

const point = { x:10, y:20, toJSON() { return [this.x, this.y]; } };
document.getElementById('output').innerHTML = JSON.stringify(point);
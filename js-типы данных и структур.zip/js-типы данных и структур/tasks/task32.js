document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>Math.round</code>, <code>Math.floor</code> и <code>Math.ceil</code> для одного и того же числа.`;

document.getElementById('solutionCode').textContent = `const n = 5.7;\nconsole.log(Math.round(n)); // 6\nconsole.log(Math.floor(n)); // 5\nconsole.log(Math.ceil(n));  // 6`;

const n = 5.7;
document.getElementById('output').innerHTML = `round: ${Math.round(n)}, floor: ${Math.floor(n)}, ceil: ${Math.ceil(n)}`;
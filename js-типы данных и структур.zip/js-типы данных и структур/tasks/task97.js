document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Какие встроенные структуры являются итерируемыми? Приведи минимум 5 примеров.`;

document.getElementById('solutionCode').innerHTML = `// Array, String, Map, Set, NodeList, arguments, TypedArray`;

document.getElementById('output').innerHTML = `Массив, строка, Map, Set, NodeList`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>replace()</code> и <code>replaceAll()</code> на одном примере.`;

document.getElementById('solutionCode').textContent = `const str = 'cat dog cat';\nconsole.log(str.replace('cat', 'mouse')); // mouse dog cat\nconsole.log(str.replaceAll('cat', 'mouse')); // mouse dog mouse`;

const str = 'cat dog cat';
document.getElementById('output').innerHTML = `replace: ${str.replace('cat', 'mouse')}, replaceAll: ${str.replaceAll('cat', 'mouse')}`;
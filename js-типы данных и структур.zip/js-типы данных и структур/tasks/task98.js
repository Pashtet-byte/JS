document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>for...of</code> для строки, массива и <code>Set</code>.`;

document.getElementById('solutionCode').textContent = `const str = 'abc';\nfor (let c of str) console.log(c);\nconst arr = [1,2,3];\nfor (let n of arr) console.log(n);\nconst set = new Set([4,5,6]);\nfor (let v of set) console.log(v);`;

let out = '';
for (let c of 'abc') out += c + ' ';
for (let n of [1,2,3]) out += n + ' ';
for (let v of new Set([4,5,6])) out += v + ' ';
document.getElementById('output').innerHTML = out;
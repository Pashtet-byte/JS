document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем итерируемый объект отличается от array-like объекта?`;

document.getElementById('solutionCode').innerHTML = `// Итерируемый объект имеет Symbol.iterator\n// Array-like объект имеет length и числовые индексы, но не обязательно итерируем\n// Пример: arguments — array-like и итерируем; {length:2, 0:'a',1:'b'} — array-like, но не итерируем`;

document.getElementById('output').innerHTML = `Итерируемый — можно использовать for...of, array-like — только по индексам.`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как поменять местами две переменные через деструктуризацию?`;

document.getElementById('solutionCode').textContent = `let a=1, b=2; [a,b] = [b,a];`;

let a=1, b=2; [a,b] = [b,a];
document.getElementById('output').innerHTML = `a=${a}, b=${b}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>map()</code>, чтобы получить массив квадратов чисел.`;

document.getElementById('solutionCode').textContent = `[1,2,3].map(x => x * x);`;

document.getElementById('output').innerHTML = [1,2,3].map(x => x * x);
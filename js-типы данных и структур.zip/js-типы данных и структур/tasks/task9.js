document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Объясни разницу между <code>typeof</code> и <code>instanceof</code> на примере массива.`;

document.getElementById('solutionCode').innerHTML = `// typeof [] → "object"\n// [] instanceof Array → true\n// [] instanceof Object → true\n// typeof показывает тип, instanceof проверяет цепочку прототипов.`;

const arr = [];
document.getElementById('output').innerHTML = `typeof [] = ${typeof arr}, [] instanceof Array = ${arr instanceof Array}, [] instanceof Object = ${arr instanceof Object}`;
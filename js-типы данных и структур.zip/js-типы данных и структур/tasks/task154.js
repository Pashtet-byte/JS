document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай вложенную деструктуризацию объекта с адресом пользователя.`;

document.getElementById('solutionCode').textContent = `const user = { name: 'Иван', address: { city: 'Москва', street: 'Тверская' } };\nconst { name, address: { city, street } } = user;`;

const user = { name: 'Иван', address: { city: 'Москва', street: 'Тверская' } };
const { name, address: { city, street } } = user;
document.getElementById('output').innerHTML = `${name}, ${city}, ${street}`;
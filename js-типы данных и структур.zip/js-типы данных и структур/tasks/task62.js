document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что происходит при обращении к несуществующему индексу массива?`;

document.getElementById('solutionCode').innerHTML = `const arr = [1,2,3];\nconsole.log(arr[10]); // undefined`;

const arr = [1,2,3];
document.getElementById('output').innerHTML = `arr[10] = ${arr[10]}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>sumDigits(n)</code>, которая считает сумму цифр числа.`;

document.getElementById('solutionCode').textContent = `function sumDigits(n) {\n  return Math.abs(n).toString().split('').reduce((s, d) => s + +d, 0);\n}`;

function sumDigits(n) { return Math.abs(n).toString().split('').reduce((s, d) => s + +d, 0); }
document.getElementById('output').innerHTML = `sumDigits(12345) = ${sumDigits(12345)}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай дату "через 7 дней" от текущего момента.`;

document.getElementById('solutionCode').textContent = `const future = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);`;

const future = new Date(Date.now() + 7*24*60*60*1000);
document.getElementById('output').innerHTML = future.toDateString();
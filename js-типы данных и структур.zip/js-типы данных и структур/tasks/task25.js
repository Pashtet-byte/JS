document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Объясни, почему <code>"abc".x = 10</code> не сохраняет свойство у строки.`;

document.getElementById('solutionCode').innerHTML = `// Строка примитивна, временный объект-обёртка создаётся и сразу уничтожается.\n// Свойство сохраняется на временном объекте, который потом исчезает.`;

let s = "abc"; s.x = 10;
document.getElementById('output').innerHTML = `s.x = ${s.x}`;
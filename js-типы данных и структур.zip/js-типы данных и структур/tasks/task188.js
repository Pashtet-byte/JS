document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй второй аргумент <code>JSON.stringify()</code> — массив разрешённых ключей.`;

document.getElementById('solutionCode').textContent = `const obj = { a:1, b:2, c:3 };\nconst json = JSON.stringify(obj, ['a','c']); // '{"a":1,"c":3}'`;

const obj = { a:1, b:2, c:3 };
const json = JSON.stringify(obj, ['a','c']);
document.getElementById('output').innerHTML = json;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему <code>WeakSet</code> хранит только объекты?`;

document.getElementById('solutionCode').innerHTML = `// Аналогично WeakMap, только объекты могут быть слабо связаны.`;

document.getElementById('output').innerHTML = `Слабые ссылки работают только с объектами.`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>slice()</code> и <code>splice()</code> и объясни разницу.`;

document.getElementById('solutionCode').innerHTML = `// slice(start, end) возвращает новый массив, не изменяя исходный\n// splice(start, deleteCount, ...items) изменяет исходный массив`;

const arr = [1,2,3,4];
const sliced = arr.slice(1,3);
const spliced = [...arr]; spliced.splice(1,2);
document.getElementById('output').innerHTML = `slice(1,3): ${sliced}, splice(1,2): ${spliced}`;
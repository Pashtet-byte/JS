document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая корректно добавляет месяцы к дате с учётом переполнения.`;

document.getElementById('solutionCode').textContent = `function addMonths(date, months) {\n  const d = new Date(date);\n  d.setMonth(d.getMonth() + months);\n  return d;\n}`;

function addMonths(d, m) { const nd = new Date(d); nd.setMonth(nd.getMonth() + m); return nd; }
const d = new Date(2024, 0, 31); // 31 января
document.getElementById('output').innerHTML = `+1 месяц: ${addMonths(d, 1).toDateString()}`;
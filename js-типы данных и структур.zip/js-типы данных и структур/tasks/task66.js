document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай пустой массив длиной 5 и объясни, чем он отличается от массива <code>[undefined, undefined, ...]</code>.`;

document.getElementById('solutionCode').innerHTML = `const arr1 = new Array(5); // [empty × 5]\nconst arr2 = [undefined, undefined, undefined, undefined, undefined];`;

const arr1 = new Array(5);
document.getElementById('output').innerHTML = `arr1 имеет ${arr1.length} элементов, но они пустые, не undefined.`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй объект, который бесконечно генерирует возрастающие числа через итератор.`;

document.getElementById('solutionCode').textContent = `const infinite = {\n  [Symbol.iterator]() {\n    let i = 0;\n    return { next() { return { value: i++, done: false }; } };\n  }\n};\n// for (let x of infinite) { if (x>10) break; console.log(x); }`;

document.getElementById('output').innerHTML = `(бесконечный генератор, используйте с break)`;
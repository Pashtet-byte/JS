document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Покажи, что <code>Set</code> хранит только уникальные значения.`;

document.getElementById('solutionCode').textContent = `const set = new Set();\nset.add(1).add(2).add(1);\nconsole.log(set.size); // 2`;

const set = new Set(); set.add(1).add(2).add(1);
document.getElementById('output').innerHTML = `size: ${set.size}`;
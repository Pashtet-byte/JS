document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Отфильтруй объект по значениям и собери новый объект обратно через <code>Object.fromEntries()</code>.`;

document.getElementById('solutionCode').textContent = `const obj = { a:1, b:2, c:3, d:4 };\nconst filtered = Object.fromEntries(Object.entries(obj).filter(([k,v]) => v % 2 === 0));`;

const obj = { a:1, b:2, c:3, d:4 };
const filtered = Object.fromEntries(Object.entries(obj).filter(([k,v]) => v % 2 === 0));
document.getElementById('output').innerHTML = JSON.stringify(filtered);
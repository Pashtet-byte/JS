document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Добавь элементы в конец массива через <code>push()</code> и в начало через <code>unshift()</code>.`;

document.getElementById('solutionCode').textContent = `const arr = [1,2];\narr.push(3);    // [1,2,3]\narr.unshift(0); // [0,1,2,3]`;

const arr = [1,2]; arr.push(3); arr.unshift(0);
document.getElementById('output').innerHTML = `[${arr}]`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Отсортируй объект по ключам, используя <code>Object.entries()</code> и <code>Object.fromEntries()</code>.`;

document.getElementById('solutionCode').textContent = `const obj = { c:3, a:1, b:2 };\nconst sorted = Object.fromEntries(Object.entries(obj).sort());`;

const obj = { c:3, a:1, b:2 };
const sorted = Object.fromEntries(Object.entries(obj).sort());
document.getElementById('output').innerHTML = JSON.stringify(sorted);
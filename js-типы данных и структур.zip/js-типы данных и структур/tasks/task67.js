document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Перебери массив тремя способами: <code>for</code>, <code>for...of</code>, <code>forEach()</code>.`;

document.getElementById('solutionCode').textContent = `const arr = [1,2,3];\nfor (let i=0; i<arr.length; i++) console.log(arr[i]);\nfor (let item of arr) console.log(item);\narr.forEach(x => console.log(x));`;

const arr = [1,2,3];
let result = '';
arr.forEach(x => result += x + ' ');
document.getElementById('output').innerHTML = result;
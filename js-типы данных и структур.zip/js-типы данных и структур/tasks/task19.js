document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>true.toString()</code> и объясни результат.`;

document.getElementById('solutionCode').innerHTML = `true.toString() → "true" // временный объект Boolean(true)`;

document.getElementById('output').innerHTML = true.toString();
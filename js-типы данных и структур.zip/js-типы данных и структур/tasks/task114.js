document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Перебери <code>Map</code> через <code>for...of</code> с деструктуризацией.`;

document.getElementById('solutionCode').textContent = `const map = new Map([['a',1], ['b',2]]);\nfor (let [key, value] of map) console.log(key, value);`;

const map = new Map([['a',1], ['b',2]]);
let out = '';
for (let [k,v] of map) out += `${k}:${v} `;
document.getElementById('output').innerHTML = out;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что происходит с функциями, <code>undefined</code> и <code>Symbol</code> при <code>JSON.stringify()</code>?`;

document.getElementById('solutionCode').innerHTML = `const obj = { f: function(){}, u: undefined, s: Symbol('id') };\nconsole.log(JSON.stringify(obj)); // {} (пропускаются)`;

const obj = { f: function(){}, u: undefined, s: Symbol('id') };
document.getElementById('output').innerHTML = JSON.stringify(obj);
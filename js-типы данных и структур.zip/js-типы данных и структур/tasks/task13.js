document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>isPlainObject(value)</code>, которая возвращает <code>true</code> только для обычных объектов.`;

document.getElementById('solutionCode').textContent = `function isPlainObject(value) {\n  return Object.prototype.toString.call(value) === '[object Object]';\n}`;

function isPlainObject(v) { return Object.prototype.toString.call(v) === '[object Object]'; }
document.getElementById('output').innerHTML = `isPlainObject({}) = ${isPlainObject({})}, isPlainObject([]) = ${isPlainObject([])}`;
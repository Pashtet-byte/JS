document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши объект, который поддерживает деструктуризацию массива через свой итератор.`;

document.getElementById('solutionCode').textContent = `const iterable = {\n  [Symbol.iterator]() {\n    let i = 0;\n    return { next() { return i < 3 ? { value: i++, done: false } : { done: true }; } };\n  }\n};\nconst [a,b,c] = iterable; // a=0,b=1,c=2`;

const iterable = { [Symbol.iterator]() { let i=0; return { next() { return i<3 ? {value:i++, done:false} : {done:true}; } }; } };
const [a,b,c] = iterable;
document.getElementById('output').innerHTML = `a=${a}, b=${b}, c=${c}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, принимающую объект и сразу деструктурирующую параметры в сигнатуре.`;

document.getElementById('solutionCode').textContent = `function greet({name, age}) {\n  return \`Привет, \${name} (\${age})\`;\n}\ngreet({name:'Иван', age:30});`;

function greet({name, age}) { return `Привет, ${name} (${age})`; }
document.getElementById('output').innerHTML = greet({name:'Иван', age:30});
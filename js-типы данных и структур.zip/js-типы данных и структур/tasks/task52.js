document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Разбей строку на массив слов через <code>split()</code> и собери обратно через <code>join()</code>.`;

document.getElementById('solutionCode').textContent = `const str = 'a,b,c';\nconst arr = str.split(',');\nconst back = arr.join(',');`;

const str = 'a,b,c';
const arr = str.split(',');
document.getElementById('output').innerHTML = `массив: ${arr.join(' | ')}, обратно: ${arr.join(',')}`;
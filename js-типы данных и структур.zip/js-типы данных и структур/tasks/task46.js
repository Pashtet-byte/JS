document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй методы <code>toUpperCase()</code> и <code>toLowerCase()</code>.`;

document.getElementById('solutionCode').textContent = `const str = 'Hello';\nconsole.log(str.toUpperCase()); // HELLO\nconsole.log(str.toLowerCase()); // hello`;

const str = 'Hello';
document.getElementById('output').innerHTML = `${str.toUpperCase()} / ${str.toLowerCase()}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Покажи на примерах, почему объекты-обёртки <code>String</code>, <code>Number</code>, <code>Boolean</code> обычно не используют.`;

document.getElementById('solutionCode').innerHTML = `// Они ведут себя неожиданно в условиях и typeof\nconst bool = new Boolean(false);\nif (bool) console.log('true'); // сработает!`;

const bool = new Boolean(false);
document.getElementById('output').innerHTML = `new Boolean(false) → ${bool}, bool ? true : false → ${bool ? 'true' : 'false'}`;
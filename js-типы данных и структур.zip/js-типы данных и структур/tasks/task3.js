document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что возвращает <code>typeof 42</code>, <code>typeof "hi"</code>, <code>typeof true</code>?`;

document.getElementById('solutionCode').innerHTML = `console.log(typeof 42);    // "number"\nconsole.log(typeof "hi");  // "string"\nconsole.log(typeof true);  // "boolean"`;

const results = `typeof 42 = ${typeof 42}, typeof "hi" = ${typeof "hi"}, typeof true = ${typeof true}`;
document.getElementById('output').innerHTML = results;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй rest-элемент в деструктуризации массива.`;

document.getElementById('solutionCode').textContent = `const [first, ...rest] = [1,2,3,4]; // first=1, rest=[2,3,4]`;

const [first, ...rest] = [1,2,3,4];
document.getElementById('output').innerHTML = `first=${first}, rest=${rest}`;
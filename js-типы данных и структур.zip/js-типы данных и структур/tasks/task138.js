document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сравни результат <code>for...in</code> и <code>Object.keys()</code>.`;

document.getElementById('solutionCode').innerHTML = `// for...in перебирает также прототипные свойства\n// Object.keys() — только собственные перечисляемые`;

const proto = { p: 1 };
const obj = Object.create(proto);
obj.a = 1;
let forin = [], keys = Object.keys(obj);
for (let k in obj) forin.push(k);
document.getElementById('output').innerHTML = `for...in: ${forin}, keys: ${keys}`;
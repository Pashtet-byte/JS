document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Как пропустить ненужные элементы массива при деструктуризации?`;

document.getElementById('solutionCode').textContent = `const [first, , third] = [1,2,3]; // first=1, third=3`;

const [first, , third] = [1,2,3];
document.getElementById('output').innerHTML = `first=${first}, third=${third}`;
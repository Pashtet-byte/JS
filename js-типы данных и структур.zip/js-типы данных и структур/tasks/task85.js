document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>reduce()</code>, чтобы собрать объект-частотность элементов массива.`;

document.getElementById('solutionCode').textContent = `const arr = ['a','b','a','c','b','a'];\nconst freq = arr.reduce((acc, x) => (acc[x] = (acc[x] || 0) + 1, acc), {});`;

const arr = ['a','b','a','c','b','a'];
const freq = arr.reduce((acc, x) => (acc[x] = (acc[x] || 0) + 1, acc), {});
document.getElementById('output').innerHTML = JSON.stringify(freq);
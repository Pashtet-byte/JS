document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай объект <code>Date</code> с текущей датой и временем.`;

document.getElementById('solutionCode').textContent = `const now = new Date();`;

const now = new Date();
document.getElementById('output').innerHTML = now.toString();
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое truthy и falsy значения? Составь таблицу из 10 примеров.`;

document.getElementById('solutionCode').innerHTML = `// falsy: false, 0, -0, 0n, "", null, undefined, NaN\n// truthy: все остальные (true, 1, [], {}, "0", "false", ...)`;

document.getElementById('output').innerHTML = `falsy: false, 0, '', null, undefined, NaN<br>truthy: true, 1, [], {}, '0'`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что произойдёт с объектом <code>Date</code> при сериализации в JSON?`;

document.getElementById('solutionCode').innerHTML = `const obj = { date: new Date() };\nconsole.log(JSON.stringify(obj)); // дата превратится в ISO-строку`;

const obj = { date: new Date() };
document.getElementById('output').innerHTML = JSON.stringify(obj);
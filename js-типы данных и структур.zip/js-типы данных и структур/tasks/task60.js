document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай массив чисел, строк и смешанный массив.`;

document.getElementById('solutionCode').innerHTML = `const nums = [1,2,3];\nconst strs = ['a','b','c'];\nconst mixed = [1,'a',true];`;

document.getElementById('output').innerHTML = `Примеры: [1,2,3], ['a','b','c'], [1,'a',true]`;
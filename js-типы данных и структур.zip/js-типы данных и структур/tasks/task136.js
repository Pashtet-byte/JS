document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>Object.entries()</code> для получения всех пар ключ-значение.`;

document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2, c:3};\nconsole.log(Object.entries(obj)); // [['a',1],['b',2],['c',3]]`;

const obj = {a:1, b:2, c:3};
document.getElementById('output').innerHTML = JSON.stringify(Object.entries(obj));
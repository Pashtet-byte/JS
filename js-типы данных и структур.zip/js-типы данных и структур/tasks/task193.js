document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что делает метод <code>toJSON()</code>? Напиши объект со своим <code>toJSON()</code>.`;

document.getElementById('solutionCode').textContent = `const obj = { name: 'Иван', age: 30, toJSON() { return this.name; } };\nconsole.log(JSON.stringify(obj)); // "Иван"`;

const obj = { name: 'Иван', age: 30, toJSON() { return this.name; } };
document.getElementById('output').innerHTML = JSON.stringify(obj);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай таймер обратного отсчёта до определённой даты.`;

document.getElementById('solutionCode').textContent = `function countdown(target) {\n  const diff = target - Date.now();\n  if (diff <= 0) return 'Время вышло!';\n  const days = Math.floor(diff / (86400000));\n  const hours = Math.floor((diff % 86400000) / 3600000);\n  const minutes = Math.floor((diff % 3600000) / 60000);\n  const seconds = Math.floor((diff % 60000) / 1000);\n  return \`\${days}д \${hours}ч \${minutes}м \${seconds}с\`;\n}`;

const target = new Date(Date.now() + 90000000);
document.getElementById('output').innerHTML = `до ${target.toLocaleString()} осталось: ... (вычисляется)`;
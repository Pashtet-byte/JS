document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай дату по строке и по набору числовых аргументов.`;

document.getElementById('solutionCode').textContent = `const d1 = new Date('2024-03-15');\nconst d2 = new Date(2024, 2, 15, 12, 30); // март (месяцы с 0)`;

const d1 = new Date('2024-03-15');
const d2 = new Date(2024, 2, 15, 12, 30);
document.getElementById('output').innerHTML = `d1: ${d1.toDateString()}, d2: ${d2.toString()}`;
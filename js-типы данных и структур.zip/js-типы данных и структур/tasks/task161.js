document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши набор упражнений, где деструктуризация заменяет длинные цепочки обращения к полям.`;

document.getElementById('solutionCode').textContent = `const obj = { user: { profile: { firstName: 'Иван', lastName: 'Петров' } } };\n// Вместо obj.user.profile.firstName\nconst { user: { profile: { firstName, lastName } } } = obj;`;

const obj = { user: { profile: { firstName: 'Иван', lastName: 'Петров' } } };
const { user: { profile: { firstName, lastName } } } = obj;
document.getElementById('output').innerHTML = `${firstName} ${lastName}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сравни поведение <code>new Number(5)</code> и числа <code>5</code> в условиях и сравнениях.`;

document.getElementById('solutionCode').innerHTML = `const n = 5, m = new Number(5);\nconsole.log(n == m);  // true\nconsole.log(n === m); // false\nconsole.log(Boolean(m)); // true (всегда)`;

const n = 5, m = new Number(5);
document.getElementById('output').innerHTML = `n == m: ${n == m}, n === m: ${n === m}, Boolean(m): ${Boolean(m)}`;
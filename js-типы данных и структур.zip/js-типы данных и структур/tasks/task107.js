document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай итерируемый объект, который при переборе пропускает элементы по условию.`;

document.getElementById('solutionCode').textContent = `const filterIterable = (obj, predicate) => ({\n  [Symbol.iterator]() {\n    const keys = Object.keys(obj);\n    let i = 0;\n    return {\n      next() {\n        while (i < keys.length) {\n          const key = keys[i++];\n          const val = obj[key];\n          if (predicate(val)) return { value: val, done: false };\n        }\n        return { done: true };\n      }\n    };\n  }\n});`;

const obj = { a:1, b:2, c:3, d:4 };
const filtered = { [Symbol.iterator]() { const vals = Object.values(obj).filter(x => x%2===0); let i=0; return { next() { return i<vals.length ? {value:vals[i++], done:false} : {done:true}; } }; } };
document.getElementById('output').innerHTML = [...filtered];
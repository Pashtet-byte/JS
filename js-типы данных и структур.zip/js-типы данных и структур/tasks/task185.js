document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Какие типы данных корректно сериализуются в JSON, а какие нет?`;

document.getElementById('solutionCode').innerHTML = `// Сериализуются: string, number, boolean, null, object, array\n// Не сериализуются: undefined, function, Symbol, bigint (ошибка), циклические ссылки (ошибка)`;

document.getElementById('output').innerHTML = `JSON поддерживает примитивы и объекты без функций.`;
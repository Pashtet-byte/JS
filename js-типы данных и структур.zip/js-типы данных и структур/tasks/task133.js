document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши задачу-сравнение: когда выбрать <code>Map</code>, а когда <code>WeakMap</code>.`;

document.getElementById('solutionCode').innerHTML = `// Map: когда нужен перебор, размер, ключи-примитивы\n// WeakMap: когда ключи-объекты и не хотим мешать сборке мусора (кэши, приватные данные)`;

document.getElementById('output').innerHTML = `Map для обычных коллекций, WeakMap для временных привязок.`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию парсинга строки вида <code>"15.03.2026 20:30"</code> в объект <code>Date</code>.`;

document.getElementById('solutionCode').textContent = `function parseDate(str) {\n  const [datePart, timePart] = str.split(' ');\n  const [d, m, y] = datePart.split('.').map(Number);\n  const [h, min] = timePart.split(':').map(Number);\n  return new Date(y, m-1, d, h, min);\n}`;

function parseDate(str) { const [date, time] = str.split(' '); const [d,m,y] = date.split('.').map(Number); const [h,min] = time.split(':').map(Number); return new Date(y,m-1,d,h,min); }
document.getElementById('output').innerHTML = parseDate('15.03.2026 20:30').toString();
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>Object.keys()</code> для получения всех ключей объекта.`;

document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2, c:3};\nconsole.log(Object.keys(obj)); // ['a','b','c']`;

const obj = {a:1, b:2, c:3};
document.getElementById('output').innerHTML = Object.keys(obj);
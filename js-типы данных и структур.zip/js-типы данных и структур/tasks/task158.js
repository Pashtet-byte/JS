document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай сложную деструктуризацию объекта с вложенными массивами и дефолтными значениями.`;

document.getElementById('solutionCode').textContent = `const data = { id: 1, info: { tags: ['js', 'fun'], meta: { views: 100 } } };\nconst { id, info: { tags: [firstTag, ...otherTags], meta: { views = 0 } } } = data;`;

const data = { id:1, info: { tags: ['js','fun'], meta: { views:100 } } };
const { id, info: { tags: [firstTag, ...otherTags], meta: { views } } } = data;
document.getElementById('output').innerHTML = `id=${id}, firstTag=${firstTag}, other=${otherTags}, views=${views}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию проверки палиндрома для строки.`;

document.getElementById('solutionCode').textContent = `function isPalindrome(str) {\n  const clean = str.toLowerCase().replace(/[^a-zа-яё]/g, '');\n  return clean === clean.split('').reverse().join('');\n}`;

function isPalindrome(s) { const c = s.toLowerCase().replace(/[^a-zа-яё]/g, ''); return c === c.split('').reverse().join(''); }
document.getElementById('output').innerHTML = `isPalindrome('А роза упала на лапу Азора') = ${isPalindrome('А роза упала на лапу Азора')}`;
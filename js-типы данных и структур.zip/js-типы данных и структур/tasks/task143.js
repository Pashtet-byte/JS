document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай функцию <code>invert(obj)</code>, которая меняет местами ключи и значения.`;

document.getElementById('solutionCode').textContent = `function invert(obj) {\n  return Object.fromEntries(Object.entries(obj).map(([k,v]) => [v, k]));\n}`;

function invert(obj) { return Object.fromEntries(Object.entries(obj).map(([k,v]) => [v,k])); }
const obj = { a:1, b:2, c:3 };
document.getElementById('output').innerHTML = JSON.stringify(invert(obj));
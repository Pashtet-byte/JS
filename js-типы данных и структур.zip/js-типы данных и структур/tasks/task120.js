document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай словарь частот слов строки через <code>Map</code>.`;

document.getElementById('solutionCode').textContent = `function wordFreq(str) {\n  return str.toLowerCase().split(/\\W+/).reduce((map, word) => {\n    if (word) map.set(word, (map.get(word) || 0) + 1);\n    return map;\n  }, new Map());\n}`;

function wordFreq(s) { return s.toLowerCase().split(/\W+/).reduce((m, w) => { if (w) m.set(w, (m.get(w)||0)+1); return m; }, new Map()); }
const freq = wordFreq('hello world hello');
document.getElementById('output').innerHTML = JSON.stringify([...freq]);
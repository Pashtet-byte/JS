document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Посчитай разницу в днях между двумя датами.`;

document.getElementById('solutionCode').textContent = `function daysBetween(d1, d2) {\n  const diff = Math.abs(d1 - d2);\n  return Math.floor(diff / (1000 * 60 * 60 * 24));\n}`;

function daysBetween(d1,d2) { return Math.floor(Math.abs(d1-d2) / (86400000)); }
const d1 = new Date(2024, 0, 1);
const d2 = new Date(2024, 0, 10);
document.getElementById('output').innerHTML = daysBetween(d1, d2);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй кэш метаданных DOM-элементов через <code>WeakMap</code>.`;

document.getElementById('solutionCode').textContent = `const metadata = new WeakMap();\n\nfunction setMeta(el, data) {\n  metadata.set(el, data);\n}\n\nfunction getMeta(el) {\n  return metadata.get(el);\n}`;

const metadata = new WeakMap();
const el = {};
setMeta(el, { x: 1 });
document.getElementById('output').innerHTML = `getMeta(el).x = ${getMeta(el).x}`;
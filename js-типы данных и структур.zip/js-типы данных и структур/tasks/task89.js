document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>fill()</code>, чтобы создать массив из одинаковых значений.`;

document.getElementById('solutionCode').textContent = `new Array(5).fill(42);`;

document.getElementById('output').innerHTML = new Array(5).fill(42);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй объект в JSON-строку через <code>JSON.stringify()</code>.`;

document.getElementById('solutionCode').textContent = `const obj = { name: 'Иван', age: 30, isAdmin: true };\nconst json = JSON.stringify(obj);`;

const obj = { name: 'Иван', age: 30, isAdmin: true };
const json = JSON.stringify(obj);
document.getElementById('output').innerHTML = json;
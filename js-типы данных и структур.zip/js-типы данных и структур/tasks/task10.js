document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая принимает любое значение и возвращает строку с его типом в человекочитаемом виде.`;

document.getElementById('solutionCode').textContent = `function humanType(value) {\n  if (value === null) return 'null';\n  if (Array.isArray(value)) return 'array';\n  return typeof value;\n}`;

function humanType(v) { if (v === null) return 'null'; if (Array.isArray(v)) return 'array'; return typeof v; }
document.getElementById('output').innerHTML = `null: ${humanType(null)}, []: ${humanType([])}, {}: ${humanType({})}, 5: ${humanType(5)}`;
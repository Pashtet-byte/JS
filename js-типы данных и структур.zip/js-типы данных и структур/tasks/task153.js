document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй rest-свойство в деструктуризации объекта.`;

document.getElementById('solutionCode').textContent = `const {a, ...rest} = {a:1, b:2, c:3}; // a=1, rest={b:2,c:3}`;

const {a, ...rest} = {a:1, b:2, c:3};
document.getElementById('output').innerHTML = `a=${a}, rest=${JSON.stringify(rest)}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>reduce()</code>, чтобы посчитать сумму элементов.`;

document.getElementById('solutionCode').textContent = `[1,2,3,4].reduce((s, x) => s + x, 0);`;

document.getElementById('output').innerHTML = [1,2,3,4].reduce((s, x) => s + x, 0);
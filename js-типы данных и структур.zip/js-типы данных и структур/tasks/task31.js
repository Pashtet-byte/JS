document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что вернёт <code>Number("123")</code> и <code>Number("123px")</code>?`;

document.getElementById('solutionCode').innerHTML = `Number("123") → 123\nNumber("123px") → NaN`;

document.getElementById('output').innerHTML = `Number("123") = ${Number("123")}, Number("123px") = ${Number("123px")}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>groupBy(arr, keyFn)</code>, которая возвращает <code>Map</code> групп.`;

document.getElementById('solutionCode').textContent = `function groupBy(arr, keyFn) {\n  return arr.reduce((map, item) => {\n    const key = keyFn(item);\n    if (!map.has(key)) map.set(key, []);\n    map.get(key).push(item);\n    return map;\n  }, new Map());\n}`;

function groupBy(arr, fn) { return arr.reduce((m, it) => { const k = fn(it); if (!m.has(k)) m.set(k, []); m.get(k).push(it); return m; }, new Map()); }
const grouped = groupBy([{t:'a'},{t:'b'},{t:'a'}], x => x.t);
document.getElementById('output').innerHTML = JSON.stringify([...grouped]);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Перечисли все примитивные типы данных в JavaScript.`;

document.getElementById('solutionCode').innerHTML = `// Примитивы: string, number, boolean, undefined, null, symbol, bigint.`;

document.getElementById('output').innerHTML = `string, number, boolean, undefined, null, symbol, bigint`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое UTC-методы у даты? Сравни их с локальными методами.`;

document.getElementById('solutionCode').innerHTML = `// UTC-методы возвращают значения в UTC (глобальное время)\n// Локальные методы возвращают в часовом поясе пользователя`;

const d = new Date();
document.getElementById('output').innerHTML = `getHours(): ${d.getHours()}, getUTCHours(): ${d.getUTCHours()}`;
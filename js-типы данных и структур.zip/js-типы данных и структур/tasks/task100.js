document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Создай собственный итерируемый объект с диапазоном чисел от <code>from</code> до <code>to</code>.`;

document.getElementById('solutionCode').textContent = `const range = {\n  from: 1, to: 5,\n  [Symbol.iterator]() {\n    let current = this.from, last = this.to;\n    return {\n      next() {\n        return current <= last ? { value: current++, done: false } : { done: true };\n      }\n    };\n  }\n};\nconsole.log([...range]); // [1,2,3,4,5]`;

const range = { from:1, to:5, [Symbol.iterator]() { let cur=this.from, last=this.to; return { next() { return cur<=last ? {value:cur++, done:false} : {done:true}; } }; } };
document.getElementById('output').innerHTML = [...range];
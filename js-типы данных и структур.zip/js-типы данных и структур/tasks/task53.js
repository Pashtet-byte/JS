document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая считает количество вхождений буквы в строке.`;

document.getElementById('solutionCode').textContent = `function countChar(str, char) {\n  return str.split('').filter(c => c === char).length;\n}`;

function countChar(s, c) { return s.split('').filter(x => x === c).length; }
document.getElementById('output').innerHTML = `countChar('hello', 'l') = ${countChar('hello', 'l')}`;
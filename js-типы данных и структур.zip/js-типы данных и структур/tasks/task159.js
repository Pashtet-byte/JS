document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>normalizeUser()</code>, которая принимает объект с пропущенными полями и через деструктуризацию собирает нормализованную структуру.`;

document.getElementById('solutionCode').textContent = `function normalizeUser({ name = 'Аноним', age = 0, email = 'не указан' } = {}) {\n  return { name, age, email };\n}`;

function normalizeUser({name='Аноним', age=0, email='не указан'}={}) { return {name,age,email}; }
document.getElementById('output').innerHTML = JSON.stringify(normalizeUser({name:'Иван'}));
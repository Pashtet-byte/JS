document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>capitalize(str)</code>, которая делает первую букву заглавной.`;

document.getElementById('solutionCode').textContent = `function capitalize(str) {\n  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();\n}`;

function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase(); }
document.getElementById('output').innerHTML = `capitalize('hello') = ${capitalize('hello')}`;
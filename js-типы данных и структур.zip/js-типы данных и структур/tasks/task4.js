document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что возвращает <code>typeof undefined</code> и <code>typeof null</code>? Объясни особенность.`;

document.getElementById('solutionCode').innerHTML = `// typeof undefined → "undefined"\n// typeof null → "object" (историческая ошибка)`;

document.getElementById('output').innerHTML = `typeof undefined = ${typeof undefined}, typeof null = ${typeof null}`;
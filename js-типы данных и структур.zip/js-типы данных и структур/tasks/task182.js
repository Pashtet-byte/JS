document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое JSON? Чем он отличается от обычного объекта JavaScript?`;

document.getElementById('solutionCode').innerHTML = `// JSON — текстовый формат обмена данными\n// Все ключи и строки в двойных кавычках, нет функций, undefined, Symbol\n// Объект JS — живая структура в памяти`;

document.getElementById('output').innerHTML = `JSON — строка, объект — структура данных.`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши собственный итератор для объекта, который перебирает только его числовые значения.`;

document.getElementById('solutionCode').textContent = `const obj = { a: 1, b: 'hello', c: 3, d: true };\nobj[Symbol.iterator] = function*() {\n  for (let key in this) {\n    if (typeof this[key] === 'number') yield this[key];\n  }\n};\nconsole.log([...obj]); // [1,3]`;

const obj = { a:1, b:'hello', c:3, d:true };
obj[Symbol.iterator] = function*() { for (let k in this) if (typeof this[k] === 'number') yield this[k]; };
document.getElementById('output').innerHTML = [...obj];
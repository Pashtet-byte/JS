document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое шаблонные строки? Собери фразу с переменными через <code>`${...}`</code>.`;

document.getElementById('solutionCode').innerHTML = `const name = 'Иван';\nconst age = 30;\nconst msg = \`Меня зовут \${name}, мне \${age} лет.\`;`;

const name = 'Иван', age = 30;
document.getElementById('output').innerHTML = `Меня зовут ${name}, мне ${age} лет.`;
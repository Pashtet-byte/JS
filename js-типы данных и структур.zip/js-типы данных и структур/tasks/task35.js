document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>isFiniteNumber(value)</code>, которая проверяет, что значение — конечное число.`;

document.getElementById('solutionCode').textContent = `function isFiniteNumber(value) {\n  return typeof value === 'number' && isFinite(value);\n}`;

function isFiniteNumber(v) { return typeof v === 'number' && isFinite(v); }
document.getElementById('output').innerHTML = `isFiniteNumber(5): ${isFiniteNumber(5)}, isFiniteNumber(Infinity): ${isFiniteNumber(Infinity)}`;
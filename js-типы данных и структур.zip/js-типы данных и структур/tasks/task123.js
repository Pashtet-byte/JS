document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай сравнение сценариев, где лучше использовать объект, а где <code>Map</code>.`;

document.getElementById('solutionCode').innerHTML = `// Объект: когда ключи строки/символы, нужна простая структура\n// Map: частые добавления/удаления, ключи-объекты, нужен size, порядок вставки`;

document.getElementById('output').innerHTML = `Map для динамических данных, объект для фиксированных структур.`;
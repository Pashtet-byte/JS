document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши мини-статью в кодовых комментариях: как работает временный объект-обёртка у примитивов.`;

document.getElementById('solutionCode').innerHTML = `// 1. Примитив не имеет методов\n// 2. При доступе к методу создаётся объект-обёртка\n// 3. Вызывается метод на объекте-обёртке\n// 4. Обёртка уничтожается, результат возвращается`;

document.getElementById('output').innerHTML = `(см. комментарии в коде)`;
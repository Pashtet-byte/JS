document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что такое итерируемый объект в JavaScript?`;

document.getElementById('solutionCode').innerHTML = `// Итерируемый объект имеет метод Symbol.iterator, возвращающий итератор.\n// Можно использовать в for...of, spread, деструктуризации.`;

document.getElementById('output').innerHTML = `Массивы, строки, Map, Set — итерируемы.`;
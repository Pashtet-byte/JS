document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй функцию <code>camelToKebab(str)</code> для преобразования <code>myVariableName</code> в <code>my-variable-name</code>.`;

document.getElementById('solutionCode').textContent = `function camelToKebab(str) {\n  return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();\n}`;

function camelToKebab(s) { return s.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase(); }
document.getElementById('output').innerHTML = `camelToKebab('myVariableName') = ${camelToKebab('myVariableName')}`;
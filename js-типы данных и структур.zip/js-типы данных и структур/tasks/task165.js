document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Чем <code>getDay()</code> отличается от <code>getDate()</code>?`;

document.getElementById('solutionCode').innerHTML = `// getDate() возвращает день месяца (1-31)\n// getDay() возвращает день недели (0-6, где 0 = воскресенье)`;

const d = new Date();
document.getElementById('output').innerHTML = `getDate(): ${d.getDate()}, getDay(): ${d.getDay()}`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию <code>mapObject(obj, fn)</code>, которая изменяет значения объекта через пары из <code>Object.entries()</code>.`;

document.getElementById('solutionCode').textContent = `function mapObject(obj, fn) {\n  return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, fn(v)]));\n}`;

function mapObject(obj, fn) { return Object.fromEntries(Object.entries(obj).map(([k,v]) => [k, fn(v)])); }
const obj = { a:1, b:2, c:3 };
document.getElementById('output').innerHTML = JSON.stringify(mapObject(obj, x => x*2));
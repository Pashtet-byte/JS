document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Покажи разницу между <code>isNaN()</code> и <code>Number.isNaN()</code>.`;

document.getElementById('solutionCode').innerHTML = `// isNaN преобразует аргумент в число, Number.isNaN не преобразует\nisNaN('abc') → true\nNumber.isNaN('abc') → false`;

document.getElementById('output').innerHTML = `isNaN('abc'): ${isNaN('abc')}, Number.isNaN('abc'): ${Number.isNaN('abc')}`;
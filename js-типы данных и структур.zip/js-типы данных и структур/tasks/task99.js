document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что делает метод <code>Symbol.iterator</code>?`;

document.getElementById('solutionCode').innerHTML = `// Symbol.iterator — это метод, который возвращает итератор для объекта.\n// Он вызывается при использовании for...of, spread, и т.д.`;

document.getElementById('output').innerHTML = `Symbol.iterator определяет поведение объекта при итерации.`;
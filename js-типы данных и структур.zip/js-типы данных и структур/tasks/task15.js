document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй утилиту <code>typeStats(arr)</code>, которая по массиву значений возвращает объект со счётчиками типов.`;

document.getElementById('solutionCode').textContent = `function typeStats(arr) {\n  return arr.reduce((acc, val) => {\n    let type = val === null ? 'null' : Array.isArray(val) ? 'array' : typeof val;\n    acc[type] = (acc[type] || 0) + 1;\n    return acc;\n  }, {});\n}`;

function typeStats(arr) { return arr.reduce((acc, v) => { let t = v === null ? 'null' : Array.isArray(v) ? 'array' : typeof v; acc[t] = (acc[t] || 0) + 1; return acc; }, {}); }
const stats = typeStats([1, 'a', true, null, [], {}, function(){}]);
document.getElementById('output').innerHTML = JSON.stringify(stats);
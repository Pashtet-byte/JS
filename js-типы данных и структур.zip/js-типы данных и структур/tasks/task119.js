document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши разность двух множеств через <code>Set</code>.`;

document.getElementById('solutionCode').textContent = `function difference(arr1, arr2) {\n  const set2 = new Set(arr2);\n  return arr1.filter(x => !set2.has(x));\n}`;

function difference(a1, a2) { const s2 = new Set(a2); return a1.filter(x => !s2.has(x)); }
document.getElementById('output').innerHTML = difference([1,2,3,4], [3,4,5,6]);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай объект-планировщик событий, который хранит массив дат и умеет находить ближайшее событие.`;

document.getElementById('solutionCode').textContent = `class Scheduler {\n  constructor(events) {\n    this.events = events.map(d => new Date(d));\n  }\n  next() {\n    const now = Date.now();\n    const future = this.events.filter(d => d > now).sort((a,b) => a - b);\n    return future.length ? future[0] : null;\n  }\n}`;

class Scheduler { constructor(e) { this.events = e.map(d => new Date(d)); } next() { const now = Date.now(); const f = this.events.filter(d => d > now).sort((a,b)=>a-b); return f.length ? f[0] : null; } }
const s = new Scheduler(['2026-03-16', '2026-03-17', '2025-01-01']);
document.getElementById('output').innerHTML = s.next() ? s.next().toDateString() : 'нет будущих';
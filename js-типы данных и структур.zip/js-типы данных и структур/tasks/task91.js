document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй массив пар вида <code>[["a",1],["b",2]]</code> в объект и обратно.`;

document.getElementById('solutionCode').textContent = `const pairs = [['a',1],['b',2]];\nconst obj = Object.fromEntries(pairs);\nconst back = Object.entries(obj);`;

const pairs = [['a',1],['b',2]];
const obj = Object.fromEntries(pairs);
document.getElementById('output').innerHTML = `obj: ${JSON.stringify(obj)}, обратно: ${JSON.stringify(Object.entries(obj))}`;
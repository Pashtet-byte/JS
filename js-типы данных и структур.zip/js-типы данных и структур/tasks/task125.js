document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Почему ключами <code>WeakMap</code> могут быть только объекты?`;

document.getElementById('solutionCode').innerHTML = `// Только объекты могут иметь слабые ссылки в JS.\n// Примитивы не могут быть собраны сборщиком мусора через WeakMap.`;

document.getElementById('output').innerHTML = `Только объекты могут быть слабо ссылаемыми.`;
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая принимает примитив и вызывает у него подходящий метод, если это возможно.`;

document.getElementById('solutionCode').textContent = `function callMethod(value, method, ...args) {\n  try {\n    return value[method]?.(...args);\n  } catch {\n    return undefined;\n  }\n}`;

function callMethod(v, m, ...a) { try { return v[m]?.(...a); } catch { return undefined; } }
document.getElementById('output').innerHTML = `callMethod("hello", "toUpperCase") = ${callMethod("hello", "toUpperCase")}`;
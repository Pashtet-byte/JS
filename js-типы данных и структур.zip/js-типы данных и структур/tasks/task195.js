document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сериализуй <code>Map</code> вручную в JSON и потом восстанови его.`;

document.getElementById('solutionCode').textContent = `const map = new Map([['a',1], ['b',2]]);\nconst json = JSON.stringify([...map]);\nconst restored = new Map(JSON.parse(json));`;

const map = new Map([['a',1], ['b',2]]);
const json = JSON.stringify([...map]);
const restored = new Map(JSON.parse(json));
document.getElementById('output').innerHTML = JSON.stringify([...restored]);
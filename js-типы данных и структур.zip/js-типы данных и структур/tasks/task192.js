document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши пример, где через <code>reviver</code> строка даты превращается обратно в объект <code>Date</code>.`;

document.getElementById('solutionCode').textContent = `const json = '{"date":"2024-03-15T12:00:00.000Z"}';\nconst obj = JSON.parse(json, (key, value) => key === 'date' ? new Date(value) : value);`;

const json = '{"date":"2024-03-15T12:00:00.000Z"}';
const obj = JSON.parse(json, (k,v) => k === 'date' ? new Date(v) : v);
document.getElementById('output').innerHTML = obj.date.toString();
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши объект с несколькими уровнями вложенности и кастомными <code>toJSON()</code> у внутренних объектов.`;

document.getElementById('solutionCode').textContent = `const obj = {\n  a: 1,\n  b: {\n    c: 2,\n    toJSON() { return 'custom'; }\n  }\n};\nconsole.log(JSON.stringify(obj)); // {"a":1,"b":"custom"}`;

const obj = { a: 1, b: { c: 2, toJSON() { return 'custom'; } } };
document.getElementById('output').innerHTML = JSON.stringify(obj);
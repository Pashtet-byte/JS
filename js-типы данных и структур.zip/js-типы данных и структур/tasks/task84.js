document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши сортировку массива чисел по возрастанию и по убыванию.`;

document.getElementById('solutionCode').textContent = `const arr = [5,2,8,1];\nconst asc = [...arr].sort((a,b) => a - b);\nconst desc = [...arr].sort((a,b) => b - a);`;

const arr = [5,2,8,1];
const asc = [...arr].sort((a,b)=>a-b);
const desc = [...arr].sort((a,b)=>b-a);
document.getElementById('output').innerHTML = `asc: ${asc}, desc: ${desc}`;
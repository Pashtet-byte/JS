document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Реализуй безопасную сериализацию объекта с циклическими ссылками.`;

document.getElementById('solutionCode').textContent = `function safeStringify(obj, replacer, space) {\n  const seen = new WeakSet();\n  return JSON.stringify(obj, (key, value) => {\n    if (typeof value === 'object' && value !== null) {\n      if (seen.has(value)) return '[Circular]';\n      seen.add(value);\n    }\n    return replacer ? replacer(key, value) : value;\n  }, space);\n}`;

function safeStringify(obj, replacer, space) { const seen = new WeakSet(); return JSON.stringify(obj, (k, v) => { if (typeof v === 'object' && v !== null) { if (seen.has(v)) return '[Circular]'; seen.add(v); } return replacer ? replacer(k,v) : v; }, space); }
const obj = {}; obj.self = obj;
document.getElementById('output').innerHTML = safeStringify(obj);
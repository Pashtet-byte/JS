document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Отсортируй массив строк по алфавиту через <code>sort()</code>.`;

document.getElementById('solutionCode').textContent = `['banana', 'apple', 'cherry'].sort();`;

document.getElementById('output').innerHTML = ['banana', 'apple', 'cherry'].sort();
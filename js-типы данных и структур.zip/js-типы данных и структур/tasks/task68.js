document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши функцию, которая разворачивает массив без использования <code>reverse()</code>.`;

document.getElementById('solutionCode').textContent = `function reverseArray(arr) {\n  const result = [];\n  for (let i = arr.length - 1; i >= 0; i--) result.push(arr[i]);\n  return result;\n}`;

function reverseArray(arr) { const r = []; for (let i=arr.length-1; i>=0; i--) r.push(arr[i]); return r; }
document.getElementById('output').innerHTML = `reverseArray([1,2,3]) = ${reverseArray([1,2,3])}`;
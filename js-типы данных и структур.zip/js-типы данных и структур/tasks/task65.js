document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что хранится в свойстве <code>length</code>? Измени его вручную и посмотри на результат.`;

document.getElementById('solutionCode').textContent = `const arr = [1,2,3];\narr.length = 2; // arr = [1,2]\narr.length = 5; // arr = [1,2,empty × 3]`;

const arr = [1,2,3]; arr.length = 2;
document.getElementById('output').innerHTML = `[${arr}]`;
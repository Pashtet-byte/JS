document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Что вернёт <code>(123.456).toFixed(2)</code>?`;

document.getElementById('solutionCode').innerHTML = `(123.456).toFixed(2) → "123.46" (строка)`;

document.getElementById('output').innerHTML = (123.456).toFixed(2);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Преобразуй объект в <code>Map</code> через <code>Object.entries()</code>.`;

document.getElementById('solutionCode').textContent = `const obj = {a:1, b:2};\nconst map = new Map(Object.entries(obj));`;

const obj = {a:1, b:2};
const map = new Map(Object.entries(obj));
document.getElementById('output').innerHTML = JSON.stringify([...map]);
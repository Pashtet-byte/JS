document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй spread-оператор для разворота итерируемого объекта в массив.`;

document.getElementById('solutionCode').textContent = `const str = 'hello';\nconst arr = [...str]; // ['h','e','l','l','o']`;

document.getElementById('output').innerHTML = [...'hello'];
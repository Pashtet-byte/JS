document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Напиши пример, где строка временно оборачивается в объект для вызова метода.`;

document.getElementById('solutionCode').textContent = `const str = "hello";\nconst upper = str.toUpperCase(); // временный объект String(str)`;

document.getElementById('output').innerHTML = `"hello".toUpperCase() = ${"hello".toUpperCase()}`;
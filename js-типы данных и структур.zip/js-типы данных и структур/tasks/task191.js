document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй второй аргумент <code>JSON.parse()</code> как функцию-reviver.`;

document.getElementById('solutionCode').textContent = `const json = '{"a":1,"b":2}';\nconst obj = JSON.parse(json, (key, value) => value * 2);`;

const json = '{"a":1,"b":2}';
const obj = JSON.parse(json, (k,v) => v * 2);
document.getElementById('output').innerHTML = JSON.stringify(obj);
document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Используй <code>some()</code> и <code>every()</code> на одном массиве.`;

document.getElementById('solutionCode').textContent = `const arr = [2,4,6,8];\nconsole.log(arr.some(x => x > 5)); // true\nconsole.log(arr.every(x => x % 2 === 0)); // true`;

const arr = [2,4,6,8];
document.getElementById('output').innerHTML = `some(x>5): ${arr.some(x=>x>5)}, every(x%2===0): ${arr.every(x=>x%2===0)}`;
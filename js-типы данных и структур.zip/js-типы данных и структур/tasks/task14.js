document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сравни поведение <code>typeof</code>, <code>Object.prototype.toString.call()</code> и <code>Array.isArray()</code> на разных значениях.`;

document.getElementById('solutionCode').textContent = `// typeof [] → "object"\n// Object.prototype.toString.call([]) → "[object Array]"\n// Array.isArray([]) → true`;

const arr = [];
document.getElementById('output').innerHTML = `typeof: ${typeof arr}, toString: ${Object.prototype.toString.call(arr)}, isArray: ${Array.isArray(arr)}`;
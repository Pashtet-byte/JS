document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>С помощью <code>map()</code> преобразуй массив строк в массив объектов.`;

document.getElementById('solutionCode').textContent = `const names = ['Иван', 'Мария'];\nconst users = names.map(name => ({ name }));`;

const names = ['Иван', 'Мария'];
const users = names.map(name => ({ name }));
document.getElementById('output').innerHTML = JSON.stringify(users);
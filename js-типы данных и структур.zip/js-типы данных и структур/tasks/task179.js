document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сравни способы форматирования даты: вручную, через <code>Intl.DateTimeFormat</code> и через ISO-строку.`;

document.getElementById('solutionCode').innerHTML = `const d = new Date();\nconst manual = d.getDate() + '.' + (d.getMonth()+1) + '.' + d.getFullYear();\nconst intl = new Intl.DateTimeFormat('ru-RU').format(d);\nconst iso = d.toISOString().slice(0,10);`;

const d = new Date();
const manual = d.getDate() + '.' + (d.getMonth()+1) + '.' + d.getFullYear();
const intl = new Intl.DateTimeFormat('ru-RU').format(d);
const iso = d.toISOString().slice(0,10);
document.getElementById('output').innerHTML = `manual: ${manual}, intl: ${intl}, iso: ${iso}`;
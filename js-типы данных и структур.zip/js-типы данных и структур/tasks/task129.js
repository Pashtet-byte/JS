document.getElementById('taskText').innerHTML = `<strong>Условие:</strong><br>Сделай пример приватного хранилища данных экземпляров через <code>WeakMap</code>.`;

document.getElementById('solutionCode').textContent = `const privateData = new WeakMap();\n\nclass User {\n  constructor(name) {\n    privateData.set(this, { name });\n  }\n  getName() {\n    return privateData.get(this).name;\n  }\n}`;

const privateData = new WeakMap();
class User { constructor(n) { privateData.set(this, { name: n }); } getName() { return privateData.get(this).name; } }
const u = new User('Иван');
document.getElementById('output').innerHTML = u.getName();